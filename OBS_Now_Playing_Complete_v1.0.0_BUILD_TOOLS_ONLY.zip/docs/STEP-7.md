# Step 7 — Animation and runtime behavior

## Completed

1. Added fade, slide-up, slide-left, and disabled transition modes.
2. Added adjustable 100–2000 ms song-change duration.
3. Added cubic ease-out motion for restrained entry animation.
4. Added smooth local progress updates between Spotify requests.
5. Added 60 Hz marquee/transition refresh and 10 Hz progress refresh only when needed.
6. Added hide-when-idle and hide-when-paused options.
7. Added immediate renderer refresh when source settings, playback, or cached artwork change.
8. Kept network and artwork downloads outside the OBS rendering path.
