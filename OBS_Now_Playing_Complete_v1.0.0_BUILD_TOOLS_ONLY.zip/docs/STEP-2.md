# Step 2 — Spotify connection and PKCE authentication

## Completed

1. Added an OBS Tools menu entry and Spotify connection window.
2. Added Spotify Client ID persistence; no client secret is accepted or stored.
3. Added cryptographically random PKCE verifier, `S256` challenge, and OAuth state.
4. Added a temporary `127.0.0.1` HTTP callback on an available port.
5. Added authorization-code exchange and automatic access-token refresh.
6. Added Windows Credential Manager storage for OAuth tokens.
7. Added explicit `invalid_grant` handling for Spotify's six-month refresh-token lifetime.
8. Added disconnect and local-credential removal behavior.

## Spotify dashboard requirement

Register this redirect URI exactly:

```text
http://127.0.0.1/callback
```

The authorization request adds a temporary port at runtime. Spotify permits this for loopback IP
literals registered without a port. `localhost` is intentionally not used.

## Implemented in later completed steps

- Current-playback polling
- Track and album parsing
- Artwork download/cache
- Visual rendering
- Full design controls
- Installer
