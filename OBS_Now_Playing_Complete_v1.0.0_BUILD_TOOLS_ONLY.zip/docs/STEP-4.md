# Step 4 — Artwork download, validation, and cache

## Completed

1. Added asynchronous HTTPS artwork downloads outside the OBS rendering thread.
2. Added no-less-safe redirect enforcement and rejected non-HTTPS final URLs.
3. Added content-type, 12 MB transfer, 4096 px dimension, and 25-megapixel limits.
4. Added format detection and full image decoding through `QImageReader`.
5. Added atomic disk writes through `QSaveFile`.
6. Preserved Spotify's original response bytes without cropping, blurring, recolouring, or re-encoding.
7. Added deterministic SHA-256 cache identities based on artwork key and URL.
8. Added in-flight request deduplication, 20-second timeout, and one-minute failure cooldown.
9. Added a 250-file/150 MB oldest-first cache limit.
10. Added cached-artwork display to the live Spotify connection preview.

## Implemented in later completed steps

- OBS GPU texture upload
- Now Playing card rendering in the scene
- Progress-bar rendering
- Gradient, font, colour, and layout controls
- Installer
