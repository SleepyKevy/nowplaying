# Step 5 — Visible OBS rendering

## Completed

1. Connected every `Now Playing` source instance to the thread-safe playback store.
2. Added a Qt card renderer for transparent, antialiased BGRA frames.
3. Added artwork loading from the validated disk cache.
4. Added dynamic `GS_BGRA` texture creation and in-place texture updates.
5. Added custom-draw rendering through OBS's standard `Draw` effect.
6. Added sRGB texture and framebuffer handling.
7. Added automatic texture recreation when the source canvas changes size.
8. Added safe GPU texture cleanup when a source is destroyed.

The source now renders a visible Now Playing card in the OBS scene.
