# Step 1 — Native plugin foundation

## Completed

1. Created a modern C++20/CMake plugin project.
2. Added libobs, OBS frontend API, and Qt 6 dependency boundaries.
3. Registered one OBS video source with a stable source ID: `obs_now_playing_source`.
4. Added persistent width and height source properties.
5. Added a provider-neutral track state model.
6. Added an asynchronous-provider interface suitable for Spotify polling.
7. Added English localization keys.

## Implemented in later completed steps

- Spotify authorization
- Access-token refresh
- Playback polling
- Album artwork download/cache
- Text and artwork rendering
- Gradient/progress-bar rendering
- Designer dock
- Installer

This separation keeps Step 1 testable and prevents authentication, networking, and OBS graphics work
from becoming tangled together.
