# Step 3 — Live Spotify playback state

## Completed

1. Added authenticated requests to `GET https://api.spotify.com/v1/me/player`.
2. Added support for Spotify tracks and podcast episodes through `additional_types`.
3. Parsed title, artist/show, album, duration, progress, state, URL, explicit/local flags, and artwork URL.
4. Added explicit advertisement, paused, stopped, unavailable, and unknown-content states.
5. Added a thread-safe snapshot store for the future OBS renderer.
6. Added local progress interpolation based on a steady clock.
7. Added five-second playing and fifteen-second idle polling intervals.
8. Added `401` token refresh, `429 Retry-After`, and exponential failure backoff.
9. Added a live playback preview to the Spotify connection window.

## Implemented in later completed steps

- Artwork file download and disk cache
- OBS texture upload
- Text/card/progress-bar rendering
- Gradient, font, colour, and layout controls
- Installer
