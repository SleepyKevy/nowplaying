# Step 8 — Release packaging and validation

## Completed

1. Promoted the project version to `1.0.0`.
2. Added CPack ZIP generation with the normal Windows OBS plugin directory layout.
3. Added a dependency-free playback state test.
4. Added static checks for localization, authentication, artwork security, renderer wiring, GPU upload,
   fonts, colors, gradient, progress, and animation features.
5. Updated the full setup, build, installation, and usage documentation.
6. Kept the release package free of BAT files and embedded credentials.

## Platform build boundary

The final DLL must be compiled on Windows against the same OBS and Qt major versions used by the target
OBS installation. Those SDK dependencies are intentionally not bundled in the source archive.
