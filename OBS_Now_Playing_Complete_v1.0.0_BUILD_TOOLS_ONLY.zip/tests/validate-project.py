#!/usr/bin/env python3
from __future__ import annotations

import re
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def main() -> int:
    cmake = (ROOT / "CMakeLists.txt").read_text(encoding="utf-8")
    plugin = (ROOT / "src/plugin-main.cpp").read_text(encoding="utf-8")
    source = (ROOT / "src/obs/now-playing-source.cpp").read_text(encoding="utf-8")
    renderer = (ROOT / "src/render/card-renderer.cpp").read_text(encoding="utf-8")
    cache = (ROOT / "src/artwork/artwork-cache.cpp").read_text(encoding="utf-8")
    auth = (ROOT / "src/spotify/spotify-auth-manager.cpp").read_text(encoding="utf-8")
    locale_text = (ROOT / "data/locale/en-US.ini").read_text(encoding="utf-8")

    locale_keys = {
        line.split("=", 1)[0].strip()
        for line in locale_text.splitlines()
        if line.strip() and not line.lstrip().startswith("#") and "=" in line
    }
    referenced_keys: set[str] = set()
    for path in (ROOT / "src").rglob("*.cpp"):
        text = path.read_text(encoding="utf-8")
        referenced_keys.update(re.findall(r'obs_module_text\("([^"]+)"\)', text))

    missing = sorted(referenced_keys - locale_keys)
    require(not missing, f"Missing locale keys: {', '.join(missing)}")
    require("VERSION 1.0.0" in cmake, "Release version is not 1.0.0")
    require("Qt6::Gui" in cmake, "Qt Gui is not linked")
    require("CardRenderer::render" in source, "OBS source does not use the card renderer")
    require("OBS_SOURCE_CUSTOM_DRAW" in source, "OBS source is not registered for custom drawing")
    require("video_tick" in source and "video_render" in source, "OBS render callbacks are incomplete")
    require("gs_texture_create" in source and "gs_texture_set_image" in source,
            "GPU texture upload is incomplete")
    require("QLinearGradient" in renderer, "Gradient rendering is missing")
    require("progress_ratio" in renderer, "Progress rendering is missing")
    require("marquee" in source.lower() and "marquee" in renderer.lower(), "Marquee support is missing")
    require("obs_properties_add_font" in source, "OBS font picker is missing")
    require("obs_properties_add_color_alpha" in source, "OBS color controls are missing")
    require("set_now_playing_playback_store" in plugin, "Playback store is not wired to the source")
    require("QNetworkRequest::NoLessSafeRedirectPolicy" in cache, "Safe artwork redirects are missing")
    require("QSaveFile" in cache, "Atomic artwork writes are missing")
    require("maximum_download_bytes" in cache, "Artwork download limit is missing")
    require("code_challenge_method" in auth and "S256" in auth, "Spotify PKCE S256 is missing")
    require("client_secret" not in auth.lower(), "A client secret must never be embedded")

    print(f"Validated {len(locale_keys)} locale keys and the complete 1.0.0 feature set.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except AssertionError as error:
        print(f"Validation failed: {error}", file=sys.stderr)
        raise SystemExit(1)
