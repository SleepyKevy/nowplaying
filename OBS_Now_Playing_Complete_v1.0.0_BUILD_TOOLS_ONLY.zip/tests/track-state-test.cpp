#include "core/playback-state-store.hpp"

#include <cassert>
#include <chrono>
#include <cmath>
#include <utility>

int main()
{
    using namespace std::chrono_literals;
    using now_playing::ContentType;
    using now_playing::PlaybackStateStore;
    using now_playing::PlaybackStatus;
    using now_playing::TrackState;

    TrackState track;
    track.track_id = "track-1";
    track.title = "Test track";
    track.content_type = ContentType::track;
    track.status = PlaybackStatus::playing;
    track.duration_ms = 200'000;
    track.progress_ms = 50'000;
    track.observed_at = std::chrono::steady_clock::now() - 2s;

    assert(track.has_track());
    assert(track.has_content());
    const auto estimated = track.estimated_progress_ms();
    assert(estimated >= 51'900 && estimated <= 52'250);
    assert(std::abs(track.progress_ratio() - 0.26) < 0.01);

    PlaybackStateStore store;
    store.update(track);
    assert(store.revision() == 1);
    assert(store.snapshot().track_id == "track-1");

    track.progress_ms = 500'000;
    track.observed_at = std::chrono::steady_clock::now();
    assert(track.estimated_progress_ms() == track.duration_ms);

    TrackState advertisement;
    advertisement.track_id = "spotify:advertisement";
    advertisement.title = "Advertisement";
    advertisement.content_type = ContentType::advertisement;
    advertisement.status = PlaybackStatus::playing;
    assert(!advertisement.has_track());
    assert(advertisement.has_content());

    store.update(std::move(advertisement));
    assert(store.revision() == 2);
    assert(store.snapshot().content_type == ContentType::advertisement);
    return 0;
}
