# OBS Now Playing 1.0

Native Windows x64 OBS Studio source plugin for a fully customizable Spotify Now Playing card.

## Complete feature set

- Spotify Authorization Code with PKCE (`S256`) and OAuth-state validation
- No client secret in the plugin
- OAuth tokens stored in Windows Credential Manager
- Automatic access-token refresh and six-month reauthorization handling
- Non-blocking current-playback polling with `401`, `429`, and failure-backoff handling
- Tracks, podcast episodes, advertisements, playing, paused, stopped, and disconnected states
- Title, artist/show, album, duration, locally smoothed progress, Spotify URL, and artwork
- HTTPS-only artwork download with response, size, dimension, and decode validation
- Atomic original-byte artwork cache with deduplication, cooldown, and cleanup limits
- Native OBS GPU texture source with transparent output outside the card
- Smooth high-quality text and artwork drawing
- Optional gradient background with two custom colors and adjustable angle
- Custom background opacity, border color/width, canvas size, padding, and corner radius
- Installed-font picker plus separate title, artist, and album sizes and colors
- Artwork visibility, side, size, and corner-radius controls
- Album visibility and left, center, or right text alignment
- Ellipsis or smooth marquee behavior for long text
- Custom progress foreground/background colors and bar height
- Optional elapsed time, total time, and playback status
- Hide-when-idle and hide-when-paused behavior
- Fade, slide-up, slide-left, or no song-change animation
- Sample-song preview mode for designing while Spotify is idle
- Spotify connection window with live metadata and artwork preview

All visual controls are inside the `Now Playing` source's normal OBS Properties window, grouped into
Layout, Background, Artwork, Typography, Progress and time, and Behavior and animation.

## Use in OBS

1. Install the compiled plugin files in the matching OBS folders.
2. Start OBS Studio.
3. Open `Tools > Now Playing: Spotify Connection`.
4. Enter the Spotify Client ID and connect the account.
5. Add a new source and choose `Now Playing`.
6. Open the source Properties to customize the design.
7. Turn on `Preview with sample song` while styling, then turn it off for live Spotify playback.

## Spotify app setup

1. Create an app in the Spotify Developer Dashboard.
2. Add `http://127.0.0.1/callback` to its redirect URI allowlist. Do not use `localhost`.
3. Copy only the app's Client ID into the OBS connection window.

The authorization request uses an available loopback port. A client secret is never requested, saved,
or shipped.

## Windows build

The Visual Studio Community IDE is **not required**. This project is set up to build with the
standalone **Build Tools for Visual Studio 2022**.

Install:

- Build Tools for Visual Studio 2022
- `Desktop development with C++` workload
- MSVC v143 x64/x86 build tools
- Windows 10/11 SDK
- CMake 3.28 or newer

You do **not** need to install OBS development files or Qt manually. On the first configure, CMake
automatically downloads the OBS/Qt dependency set pinned by `buildspec.json`, verifies SHA-256
hashes, builds the small OBS development SDK needed by this plugin, and caches everything under
`.deps/`.

### Easiest build

Open PowerShell in the project folder and run:

```powershell
.\BUILD_WINDOWS.ps1
```

### Manual commands

```powershell
cmake --preset windows-x64
cmake --build --preset windows-x64
cd build_x64
cpack -C RelWithDebInfo
```

The final package is:

```text
build_x64\OBS-Now-Playing-1.0.0-Windows-x64.zip
```

Merge the package's `obs-plugins` and `data` folders into your OBS Studio installation folder.

The first build needs internet access because the build bootstrap downloads OBS and Qt development
dependencies. Later builds reuse the `.deps` cache.

## Validation

Run the dependency-free checks with:

```powershell
python tests/validate-project.py
g++ -std=c++20 -pthread -Isrc tests/track-state-test.cpp -o state-test.exe
./state-test.exe
```

The full module must also be compiled and tested inside OBS on Windows because the OBS SDK and matching
Qt libraries are not vendored in this repository.

## Project layout

```text
src/plugin-main.cpp                    Module entry point and runtime services
src/artwork/artwork-cache.*            Secure artwork download and original-byte cache
src/core/track-state.hpp               Playback and artwork state model
src/core/playback-state-store.hpp      Thread-safe latest-playback snapshot
src/services/playback-provider.hpp     Provider boundary
src/spotify/spotify-auth-manager.*     PKCE, callback, token exchange, refresh
src/spotify/spotify-playback-provider.* Spotify current-playback polling and parsing
src/security/credential-store.*        Windows Credential Manager wrapper
src/render/render-config.hpp           All visual settings
src/render/card-renderer.*             Qt card, text, artwork, gradient, and progress rendering
src/obs/now-playing-source.*           OBS properties, tick, GPU upload, and video rendering
src/ui/spotify-connection-dialog.*     Spotify setup and live preview window
data/locale/en-US.ini                  OBS-facing labels
tests/                                 Dependency-free state and static validation
docs/STEP-*.md                         Implementation stages
```
