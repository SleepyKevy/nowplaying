[CmdletBinding()]
param(
    [ValidateSet('RelWithDebInfo', 'Release', 'Debug', 'MinSizeRel')]
    [string]$Configuration = 'RelWithDebInfo',
    [switch]$Clean
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ProjectRoot

function Require-Command([string]$Name, [string]$InstallHint) {
    if (-not (Get-Command $Name -ErrorAction SilentlyContinue)) {
        throw "$Name was not found. $InstallHint"
    }
}

if ($env:OS -ne 'Windows_NT') {
    throw 'This build script is for Windows x64.'
}

Require-Command 'cmake' 'Install CMake 3.28-3.30 and add it to PATH.'
Require-Command 'cpack' 'CPack is installed with CMake; repair/reinstall CMake if it is missing.'

$cmakeVersionLine = (& cmake --version | Select-Object -First 1)
if ($cmakeVersionLine -notmatch '(\d+)\.(\d+)\.(\d+)') {
    throw "Unable to determine CMake version from: $cmakeVersionLine"
}
$cmakeVersion = [version]::new([int]$Matches[1], [int]$Matches[2], [int]$Matches[3])
if ($cmakeVersion -lt [version]'3.28.0') {
    throw "CMake 3.28 or newer is required. Detected $cmakeVersion."
}

$generators = (& cmake --help)
if (($generators -join "`n") -notmatch 'Visual Studio 17 2022') {
    throw @'
CMake cannot see the Visual Studio 17 2022 generator.
Install "Build Tools for Visual Studio 2022" (NOT Visual Studio Community) and select:
  - Desktop development with C++
  - MSVC v143 x64/x86 build tools
  - Windows 10/11 SDK
Then reopen PowerShell and run this script again.
'@
}

if ($Clean) {
    Remove-Item -Recurse -Force "$ProjectRoot\build_x64" -ErrorAction SilentlyContinue
}

Write-Host '==> Configuring plugin and downloading OBS/Qt development dependencies...'
& cmake --preset windows-x64
if ($LASTEXITCODE -ne 0) { throw "CMake configure failed with exit code $LASTEXITCODE." }

Write-Host "==> Building $Configuration..."
& cmake --build --preset windows-x64 --config $Configuration
if ($LASTEXITCODE -ne 0) { throw "CMake build failed with exit code $LASTEXITCODE." }

Write-Host '==> Packaging OBS plugin ZIP...'
Push-Location "$ProjectRoot\build_x64"
try {
    & cpack -C $Configuration
    if ($LASTEXITCODE -ne 0) { throw "CPack failed with exit code $LASTEXITCODE." }
}
finally {
    Pop-Location
}

$package = Get-ChildItem "$ProjectRoot\build_x64\OBS-Now-Playing-1.0.0-Windows-x64.zip" -ErrorAction Stop
Write-Host ''
Write-Host 'BUILD COMPLETE'
Write-Host "Package: $($package.FullName)"
