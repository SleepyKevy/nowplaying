#pragma once

#include <QByteArray>
#include <QNetworkAccessManager>
#include <QObject>
#include <QPointer>
#include <QString>
#include <QTcpServer>
#include <QUrl>

class QNetworkReply;
class QTcpSocket;

namespace now_playing {

class SpotifyAuthManager final : public QObject {
    Q_OBJECT

public:
    enum class Status {
        disconnected,
        waiting_for_browser,
        exchanging_code,
        connected,
        reauthorization_required,
        error,
    };
    Q_ENUM(Status)

    explicit SpotifyAuthManager(QObject* parent = nullptr);
    ~SpotifyAuthManager() override;

    [[nodiscard]] QString client_id() const;
    void set_client_id(const QString& client_id);

    [[nodiscard]] Status status() const noexcept;
    [[nodiscard]] QString status_message() const;
    [[nodiscard]] bool has_access_token() const;
    [[nodiscard]] QString access_token() const;

    void connect_spotify();
    void disconnect_spotify();
    void ensure_valid_access_token();
    void force_refresh_access_token();

signals:
    void status_changed(now_playing::SpotifyAuthManager::Status status, const QString& message);
    void access_token_ready(const QString& access_token);

private:
    struct TokenData {
        QString access_token;
        QString refresh_token;
        qint64 access_expires_at = 0;
        qint64 authorized_at = 0;
    };

    void set_status(Status status, const QString& message);
    void begin_callback_server();
    void handle_callback_connection();
    void handle_callback_request(QTcpSocket* socket, const QUrl& request_url);
    void exchange_authorization_code(const QString& code);
    void refresh_access_token();
    void handle_token_reply(QNetworkReply* reply, bool is_refresh);
    void send_browser_response(QTcpSocket* socket, bool success, const QString& message);

    [[nodiscard]] QByteArray random_urlsafe(int byte_count) const;
    [[nodiscard]] QString load_client_id() const;
    void save_client_id() const;
    [[nodiscard]] bool load_tokens();
    [[nodiscard]] bool save_tokens();
    void clear_tokens();

    QString client_id_;
    QString pkce_verifier_;
    QString oauth_state_;
    QUrl redirect_uri_;
    TokenData tokens_;
    Status status_ = Status::disconnected;
    QString status_message_;
    bool token_request_in_flight_ = false;
    QPointer<QNetworkReply> token_reply_;
    QTcpServer callback_server_;
    QNetworkAccessManager network_;
};

} // namespace now_playing
