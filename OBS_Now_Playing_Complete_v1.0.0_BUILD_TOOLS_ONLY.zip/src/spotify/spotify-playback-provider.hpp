#pragma once

#include "../services/playback-provider.hpp"

#include <QByteArray>
#include <QNetworkAccessManager>
#include <QObject>
#include <QPointer>
#include <QTimer>

class QNetworkReply;

namespace now_playing {

class SpotifyAuthManager;

class SpotifyPlaybackProvider final : public QObject, public PlaybackProvider {
    Q_OBJECT

public:
    explicit SpotifyPlaybackProvider(SpotifyAuthManager& auth, QObject* parent = nullptr);
    ~SpotifyPlaybackProvider() override;

    void start(StateHandler on_state, ErrorHandler on_error) override;
    void stop() override;
    [[nodiscard]] bool is_connected() const noexcept override;

private:
    void schedule_poll(int delay_ms);
    void poll_now();
    void handle_reply(QNetworkReply* reply);
    void publish(TrackState state);
    void publish_empty(PlaybackStatus status);
    void report_error(const QString& message);
    void schedule_failure_backoff();

    [[nodiscard]] static bool parse_playback(const QByteArray& body, TrackState* state,
                                             QString* error);

    SpotifyAuthManager& auth_;
    QTimer poll_timer_;
    QNetworkAccessManager network_;
    QPointer<QNetworkReply> playback_reply_;
    StateHandler on_state_;
    ErrorHandler on_error_;
    bool running_ = false;
    int consecutive_failures_ = 0;
};

} // namespace now_playing
