#include "spotify-auth-manager.hpp"

#include "../security/credential-store.hpp"

#include <obs-module.h>
#include <util/bmem.h>

#include <QCryptographicHash>
#include <QDateTime>
#include <QDesktopServices>
#include <QDir>
#include <QFileInfo>
#include <QHostAddress>
#include <QJsonDocument>
#include <QJsonObject>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QRandomGenerator>
#include <QSettings>
#include <QTcpSocket>
#include <QUrlQuery>
#include <QVariant>

#include <algorithm>

namespace now_playing {
namespace {

constexpr auto credential_target = "SleepyKev.OBSNowPlaying.SpotifyOAuth";
constexpr auto authorize_endpoint = "https://accounts.spotify.com/authorize";
constexpr auto token_endpoint = "https://accounts.spotify.com/api/token";
constexpr qint64 token_expiry_margin_seconds = 60;

QString settings_path()
{
    char* path = obs_module_config_path("spotify-auth.ini");
    if (!path) {
        return {};
    }

    const QString result = QString::fromUtf8(path);
    bfree(path);
    QDir().mkpath(QFileInfo(result).absolutePath());
    return result;
}

QString json_error_message(const QByteArray& body, const QString& fallback)
{
    const QJsonObject object = QJsonDocument::fromJson(body).object();
    const QString description = object.value(QStringLiteral("error_description")).toString();
    if (!description.isEmpty()) {
        return description;
    }

    const QString error = object.value(QStringLiteral("error")).toString();
    return error.isEmpty() ? fallback : error;
}

} // namespace

SpotifyAuthManager::SpotifyAuthManager(QObject* parent) : QObject(parent), client_id_(load_client_id())
{
    connect(&callback_server_, &QTcpServer::newConnection, this, &SpotifyAuthManager::handle_callback_connection);

    if (!client_id_.isEmpty() && load_tokens()) {
        if (has_access_token()) {
            set_status(Status::connected, obs_module_text("SpotifyConnection.Connected"));
        } else {
            ensure_valid_access_token();
        }
    } else if (status_ != Status::error) {
        set_status(Status::disconnected, obs_module_text("SpotifyConnection.Disconnected"));
    }
}

SpotifyAuthManager::~SpotifyAuthManager()
{
    callback_server_.close();
}

QString SpotifyAuthManager::client_id() const
{
    return client_id_;
}

void SpotifyAuthManager::set_client_id(const QString& client_id)
{
    const QString cleaned = client_id.trimmed();
    if (client_id_ == cleaned) {
        return;
    }

    client_id_ = cleaned;
    clear_tokens();
    save_client_id();
}

SpotifyAuthManager::Status SpotifyAuthManager::status() const noexcept
{
    return status_;
}

QString SpotifyAuthManager::status_message() const
{
    return status_message_;
}

bool SpotifyAuthManager::has_access_token() const
{
    return !tokens_.access_token.isEmpty() &&
           QDateTime::currentSecsSinceEpoch() < tokens_.access_expires_at - token_expiry_margin_seconds;
}

QString SpotifyAuthManager::access_token() const
{
    return has_access_token() ? tokens_.access_token : QString{};
}

void SpotifyAuthManager::connect_spotify()
{
    if (client_id_.isEmpty()) {
        set_status(Status::error, obs_module_text("SpotifyConnection.MissingClientId"));
        return;
    }

    clear_tokens();
    begin_callback_server();
    if (!callback_server_.isListening()) {
        return;
    }

    pkce_verifier_ = QString::fromLatin1(random_urlsafe(64));
    oauth_state_ = QString::fromLatin1(random_urlsafe(32));
    const QByteArray challenge = QCryptographicHash::hash(pkce_verifier_.toLatin1(),
                                                          QCryptographicHash::Sha256)
                                     .toBase64(QByteArray::Base64UrlEncoding |
                                               QByteArray::OmitTrailingEquals);

    QUrl authorization_url(QString::fromLatin1(authorize_endpoint));
    QUrlQuery query;
    query.addQueryItem(QStringLiteral("response_type"), QStringLiteral("code"));
    query.addQueryItem(QStringLiteral("client_id"), client_id_);
    query.addQueryItem(QStringLiteral("redirect_uri"), redirect_uri_.toString());
    query.addQueryItem(QStringLiteral("scope"),
                       QStringLiteral("user-read-playback-state user-read-currently-playing"));
    query.addQueryItem(QStringLiteral("code_challenge_method"), QStringLiteral("S256"));
    query.addQueryItem(QStringLiteral("code_challenge"), QString::fromLatin1(challenge));
    query.addQueryItem(QStringLiteral("state"), oauth_state_);
    authorization_url.setQuery(query);

    set_status(Status::waiting_for_browser, obs_module_text("SpotifyConnection.Waiting"));
    if (!QDesktopServices::openUrl(authorization_url)) {
        callback_server_.close();
        set_status(Status::error, QStringLiteral("Unable to open the Spotify authorization page"));
    }
}

void SpotifyAuthManager::disconnect_spotify()
{
    callback_server_.close();
    clear_tokens();
    set_status(Status::disconnected, obs_module_text("SpotifyConnection.Disconnected"));
}

void SpotifyAuthManager::ensure_valid_access_token()
{
    if (has_access_token()) {
        set_status(Status::connected, obs_module_text("SpotifyConnection.Connected"));
        emit access_token_ready(tokens_.access_token);
        return;
    }

    if (!tokens_.refresh_token.isEmpty()) {
        refresh_access_token();
        return;
    }

    set_status(Status::disconnected, obs_module_text("SpotifyConnection.Disconnected"));
}

void SpotifyAuthManager::force_refresh_access_token()
{
    if (tokens_.refresh_token.isEmpty()) {
        set_status(Status::reauthorization_required,
                   obs_module_text("SpotifyConnection.Reauthorization"));
        return;
    }

    tokens_.access_token.clear();
    tokens_.access_expires_at = 0;
    refresh_access_token();
}

void SpotifyAuthManager::set_status(Status status, const QString& message)
{
    status_ = status;
    status_message_ = message;
    emit status_changed(status_, status_message_);
}

void SpotifyAuthManager::begin_callback_server()
{
    callback_server_.close();
    if (!callback_server_.listen(QHostAddress(QHostAddress::LocalHost), 0)) {
        set_status(Status::error, QStringLiteral("Unable to start the private Spotify callback server"));
        return;
    }

    redirect_uri_ = QUrl(QStringLiteral("http://127.0.0.1:%1/callback").arg(callback_server_.serverPort()));
}

void SpotifyAuthManager::handle_callback_connection()
{
    while (QTcpSocket* socket = callback_server_.nextPendingConnection()) {
        socket->setParent(this);
        connect(socket, &QTcpSocket::readyRead, this, [this, socket] {
            QByteArray request = socket->property("spotify_request").toByteArray();
            request.append(socket->readAll());
            if (!request.contains("\r\n\r\n")) {
                socket->setProperty("spotify_request", request);
                return;
            }

            socket->setProperty("spotify_request", QVariant{});
            const QList<QByteArray> first_line_parts = request.left(request.indexOf("\r\n")).split(' ');
            if (first_line_parts.size() < 2 || first_line_parts.at(0) != "GET") {
                send_browser_response(socket, false, QStringLiteral("Invalid callback request"));
                return;
            }

            const QUrl request_url(QStringLiteral("http://127.0.0.1") +
                                   QString::fromUtf8(first_line_parts.at(1)));
            handle_callback_request(socket, request_url);
        });
        connect(socket, &QTcpSocket::disconnected, socket, &QObject::deleteLater);
    }
}

void SpotifyAuthManager::handle_callback_request(QTcpSocket* socket, const QUrl& request_url)
{
    const QUrlQuery query(request_url);
    const QString returned_state = query.queryItemValue(QStringLiteral("state"));
    if (returned_state.isEmpty() || returned_state != oauth_state_) {
        send_browser_response(socket, false, QStringLiteral("Spotify security-state validation failed"));
        set_status(Status::error, QStringLiteral("Spotify security-state validation failed"));
        callback_server_.close();
        return;
    }

    const QString authorization_error = query.queryItemValue(QStringLiteral("error"));
    if (!authorization_error.isEmpty()) {
        send_browser_response(socket, false, QStringLiteral("Spotify authorization was declined"));
        set_status(Status::disconnected, QStringLiteral("Spotify authorization was declined"));
        callback_server_.close();
        return;
    }

    const QString code = query.queryItemValue(QStringLiteral("code"));
    if (code.isEmpty()) {
        send_browser_response(socket, false, QStringLiteral("Spotify did not return an authorization code"));
        set_status(Status::error, QStringLiteral("Spotify did not return an authorization code"));
        callback_server_.close();
        return;
    }

    send_browser_response(socket, true, QStringLiteral("Spotify is connected. You can return to OBS."));
    callback_server_.close();
    exchange_authorization_code(code);
}

void SpotifyAuthManager::exchange_authorization_code(const QString& code)
{
    if (token_request_in_flight_) {
        return;
    }
    token_request_in_flight_ = true;
    set_status(Status::exchanging_code, obs_module_text("SpotifyConnection.Exchanging"));

    QUrlQuery form;
    form.addQueryItem(QStringLiteral("grant_type"), QStringLiteral("authorization_code"));
    form.addQueryItem(QStringLiteral("code"), code);
    form.addQueryItem(QStringLiteral("redirect_uri"), redirect_uri_.toString());
    form.addQueryItem(QStringLiteral("client_id"), client_id_);
    form.addQueryItem(QStringLiteral("code_verifier"), pkce_verifier_);

    QNetworkRequest request{QUrl(QString::fromLatin1(token_endpoint))};
    request.setHeader(QNetworkRequest::ContentTypeHeader, QStringLiteral("application/x-www-form-urlencoded"));
    QNetworkReply* reply = network_.post(request, form.query(QUrl::FullyEncoded).toUtf8());
    token_reply_ = reply;
    connect(reply, &QNetworkReply::finished, this, [this, reply] { handle_token_reply(reply, false); });
}

void SpotifyAuthManager::refresh_access_token()
{
    if (token_request_in_flight_ || client_id_.isEmpty() || tokens_.refresh_token.isEmpty()) {
        return;
    }
    token_request_in_flight_ = true;

    QUrlQuery form;
    form.addQueryItem(QStringLiteral("grant_type"), QStringLiteral("refresh_token"));
    form.addQueryItem(QStringLiteral("refresh_token"), tokens_.refresh_token);
    form.addQueryItem(QStringLiteral("client_id"), client_id_);

    QNetworkRequest request{QUrl(QString::fromLatin1(token_endpoint))};
    request.setHeader(QNetworkRequest::ContentTypeHeader, QStringLiteral("application/x-www-form-urlencoded"));
    QNetworkReply* reply = network_.post(request, form.query(QUrl::FullyEncoded).toUtf8());
    token_reply_ = reply;
    connect(reply, &QNetworkReply::finished, this, [this, reply] { handle_token_reply(reply, true); });
}

void SpotifyAuthManager::handle_token_reply(QNetworkReply* reply, bool is_refresh)
{
    if (token_reply_ != reply) {
        reply->deleteLater();
        return;
    }
    token_reply_ = nullptr;
    token_request_in_flight_ = false;
    const QByteArray body = reply->readAll();
    const int status_code = reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();
    const QJsonObject object = QJsonDocument::fromJson(body).object();
    reply->deleteLater();

    if (status_code < 200 || status_code >= 300) {
        const QString oauth_error = object.value(QStringLiteral("error")).toString();
        if (is_refresh && oauth_error == QStringLiteral("invalid_grant")) {
            clear_tokens();
            set_status(Status::reauthorization_required,
                       obs_module_text("SpotifyConnection.Reauthorization"));
            return;
        }
        set_status(Status::error, json_error_message(body, QStringLiteral("Spotify token request failed")));
        return;
    }

    const QString access_token = object.value(QStringLiteral("access_token")).toString();
    const qint64 expires_in = object.value(QStringLiteral("expires_in")).toInteger();
    if (access_token.isEmpty() || expires_in <= 0) {
        set_status(Status::error, QStringLiteral("Spotify returned an incomplete token response"));
        return;
    }

    tokens_.access_token = access_token;
    const QString replacement_refresh = object.value(QStringLiteral("refresh_token")).toString();
    if (!replacement_refresh.isEmpty()) {
        tokens_.refresh_token = replacement_refresh;
    }
    if (!is_refresh || tokens_.authorized_at == 0) {
        tokens_.authorized_at = QDateTime::currentSecsSinceEpoch();
    }
    tokens_.access_expires_at = QDateTime::currentSecsSinceEpoch() + expires_in;

    if (!save_tokens()) {
        return;
    }

    pkce_verifier_.clear();
    oauth_state_.clear();
    set_status(Status::connected, obs_module_text("SpotifyConnection.Connected"));
    emit access_token_ready(tokens_.access_token);
}

void SpotifyAuthManager::send_browser_response(QTcpSocket* socket, bool success, const QString& message)
{
    const QString color = success ? QStringLiteral("#1ed760") : QStringLiteral("#ff5c7a");
    const QByteArray body = QStringLiteral(
                                "<!doctype html><html><head><meta charset=\"utf-8\"><title>OBS Now "
                                "Playing</title></head><body style=\"margin:0;background:#11141b;color:#fff;"
                                "font-family:Segoe UI,sans-serif;display:grid;place-items:center;min-height:100vh\">"
                                "<main style=\"max-width:620px;padding:40px;text-align:center\"><h1 style=\"color:%1\">"
                                "OBS Now Playing</h1><p>%2</p></main></body></html>")
                                .arg(color, message.toHtmlEscaped())
                                .toUtf8();
    const QByteArray header = "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\n"
                              "Connection: close\r\nCache-Control: no-store\r\nContent-Length: " +
                              QByteArray::number(body.size()) + "\r\n\r\n";
    socket->write(header);
    socket->write(body);
    socket->disconnectFromHost();
}

QByteArray SpotifyAuthManager::random_urlsafe(int byte_count) const
{
    QByteArray bytes(byte_count, Qt::Uninitialized);
    auto* generator = QRandomGenerator::system();
    for (int offset = 0; offset < byte_count; offset += static_cast<int>(sizeof(quint32))) {
        const quint32 value = generator->generate();
        const int count = std::min(static_cast<int>(sizeof(value)), byte_count - offset);
        std::copy_n(reinterpret_cast<const char*>(&value), count, bytes.data() + offset);
    }
    return bytes.toBase64(QByteArray::Base64UrlEncoding | QByteArray::OmitTrailingEquals);
}

QString SpotifyAuthManager::load_client_id() const
{
    const QString path = settings_path();
    if (path.isEmpty()) {
        return {};
    }

    QSettings settings(path, QSettings::IniFormat);
    return settings.value(QStringLiteral("spotify/client_id")).toString().trimmed();
}

void SpotifyAuthManager::save_client_id() const
{
    const QString path = settings_path();
    if (path.isEmpty()) {
        return;
    }

    QSettings settings(path, QSettings::IniFormat);
    settings.setValue(QStringLiteral("spotify/client_id"), client_id_);
    settings.sync();
}

bool SpotifyAuthManager::load_tokens()
{
    QString error;
    const auto stored = CredentialStore::read(QString::fromLatin1(credential_target), &error);
    if (!stored) {
        if (!error.isEmpty()) {
            set_status(Status::error, error);
        }
        return false;
    }

    const QJsonObject object = QJsonDocument::fromJson(*stored).object();
    tokens_.access_token = object.value(QStringLiteral("access_token")).toString();
    tokens_.refresh_token = object.value(QStringLiteral("refresh_token")).toString();
    tokens_.access_expires_at = object.value(QStringLiteral("access_expires_at")).toInteger();
    tokens_.authorized_at = object.value(QStringLiteral("authorized_at")).toInteger();
    return !tokens_.refresh_token.isEmpty();
}

bool SpotifyAuthManager::save_tokens()
{
    QJsonObject object;
    object.insert(QStringLiteral("access_token"), tokens_.access_token);
    object.insert(QStringLiteral("refresh_token"), tokens_.refresh_token);
    object.insert(QStringLiteral("access_expires_at"), tokens_.access_expires_at);
    object.insert(QStringLiteral("authorized_at"), tokens_.authorized_at);
    const QByteArray serialized = QJsonDocument(object).toJson(QJsonDocument::Compact);

    QString error;
    if (!CredentialStore::write(QString::fromLatin1(credential_target), serialized, &error)) {
        set_status(Status::error, error);
        return false;
    }
    return true;
}

void SpotifyAuthManager::clear_tokens()
{
    if (token_reply_) {
        QObject::disconnect(token_reply_.data(), nullptr, this, nullptr);
        token_reply_->abort();
        token_reply_->deleteLater();
        token_reply_ = nullptr;
    }
    tokens_ = {};
    token_request_in_flight_ = false;
    pkce_verifier_.clear();
    oauth_state_.clear();
    QString ignored_error;
    CredentialStore::remove(QString::fromLatin1(credential_target), &ignored_error);
}

} // namespace now_playing
