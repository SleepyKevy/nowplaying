#include "spotify-playback-provider.hpp"

#include "spotify-auth-manager.hpp"

#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonParseError>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QStringList>
#include <QUrlQuery>

#include <algorithm>
#include <chrono>
#include <cstdint>
#include <string>
#include <utility>

namespace now_playing {
namespace {

constexpr auto playback_endpoint = "https://api.spotify.com/v1/me/player";
constexpr int playing_poll_ms = 5'000;
constexpr int idle_poll_ms = 15'000;
constexpr int maximum_failure_backoff_ms = 60'000;

std::string to_utf8(const QString& value)
{
    return value.toUtf8().toStdString();
}

QString joined_artist_names(const QJsonArray& artists)
{
    QStringList names;
    for (const QJsonValue& value : artists) {
        const QString name = value.toObject().value(QStringLiteral("name")).toString().trimmed();
        if (!name.isEmpty()) {
            names.push_back(name);
        }
    }
    return names.join(QStringLiteral(", "));
}

ArtworkReference choose_artwork(const QJsonArray& images, const QString& cache_key)
{
    QJsonObject selected;
    qint64 selected_area = -1;
    for (const QJsonValue& value : images) {
        const QJsonObject image = value.toObject();
        if (image.value(QStringLiteral("url")).toString().isEmpty()) {
            continue;
        }

        const qint64 width = image.value(QStringLiteral("width")).toInteger();
        const qint64 height = image.value(QStringLiteral("height")).toInteger();
        const qint64 area = width > 0 && height > 0 ? width * height : 0;
        if (selected.isEmpty() || area > selected_area) {
            selected = image;
            selected_area = area;
        }
    }

    ArtworkReference artwork;
    artwork.url = to_utf8(selected.value(QStringLiteral("url")).toString());
    artwork.cache_key = to_utf8(cache_key);
    artwork.width = static_cast<std::uint32_t>(
        std::max<qint64>(0, selected.value(QStringLiteral("width")).toInteger()));
    artwork.height = static_cast<std::uint32_t>(
        std::max<qint64>(0, selected.value(QStringLiteral("height")).toInteger()));
    return artwork;
}

QString external_spotify_url(const QJsonObject& object)
{
    return object.value(QStringLiteral("external_urls"))
        .toObject()
        .value(QStringLiteral("spotify"))
        .toString();
}

} // namespace

SpotifyPlaybackProvider::SpotifyPlaybackProvider(SpotifyAuthManager& auth, QObject* parent)
    : QObject(parent), auth_(auth)
{
    poll_timer_.setSingleShot(true);
    connect(&poll_timer_, &QTimer::timeout, this, &SpotifyPlaybackProvider::poll_now);
    connect(&auth_, &SpotifyAuthManager::access_token_ready, this,
            [this](const QString&) {
                if (running_) {
                    schedule_poll(0);
                }
            });
    connect(&auth_, &SpotifyAuthManager::status_changed, this,
            [this](SpotifyAuthManager::Status status, const QString&) {
                if (!running_) {
                    return;
                }
                if (status == SpotifyAuthManager::Status::connected) {
                    schedule_poll(0);
                } else if (status == SpotifyAuthManager::Status::disconnected ||
                           status == SpotifyAuthManager::Status::reauthorization_required) {
                    poll_timer_.stop();
                    publish_empty(PlaybackStatus::unavailable);
                }
            });
}

SpotifyPlaybackProvider::~SpotifyPlaybackProvider()
{
    stop();
}

void SpotifyPlaybackProvider::start(StateHandler on_state, ErrorHandler on_error)
{
    on_state_ = std::move(on_state);
    on_error_ = std::move(on_error);
    running_ = true;
    consecutive_failures_ = 0;

    if (auth_.status() == SpotifyAuthManager::Status::connected) {
        schedule_poll(0);
    } else {
        auth_.ensure_valid_access_token();
    }
}

void SpotifyPlaybackProvider::stop()
{
    running_ = false;
    poll_timer_.stop();
    if (playback_reply_) {
        QObject::disconnect(playback_reply_.data(), nullptr, this, nullptr);
        playback_reply_->abort();
        playback_reply_->deleteLater();
        playback_reply_ = nullptr;
    }
    on_state_ = {};
    on_error_ = {};
}

bool SpotifyPlaybackProvider::is_connected() const noexcept
{
    return running_ && auth_.status() == SpotifyAuthManager::Status::connected;
}

void SpotifyPlaybackProvider::schedule_poll(int delay_ms)
{
    if (!running_) {
        return;
    }
    poll_timer_.start(std::max(0, delay_ms));
}

void SpotifyPlaybackProvider::poll_now()
{
    if (!running_ || playback_reply_) {
        return;
    }

    const QString token = auth_.access_token();
    if (token.isEmpty()) {
        auth_.ensure_valid_access_token();
        return;
    }

    QUrl url(QString::fromLatin1(playback_endpoint));
    QUrlQuery query;
    query.addQueryItem(QStringLiteral("additional_types"), QStringLiteral("track,episode"));
    url.setQuery(query);

    QNetworkRequest request{url};
    request.setRawHeader("Authorization", QByteArray("Bearer ") + token.toUtf8());
    request.setRawHeader("Accept", "application/json");
    request.setHeader(QNetworkRequest::UserAgentHeader,
                      QStringLiteral("OBS-Now-Playing/%1").arg(QStringLiteral(NOWPLAYING_PLUGIN_VERSION)));
    playback_reply_ = network_.get(request);
    QNetworkReply* reply = playback_reply_.data();
    connect(reply, &QNetworkReply::finished, this, [this, reply] { handle_reply(reply); });
}

void SpotifyPlaybackProvider::handle_reply(QNetworkReply* reply)
{
    if (playback_reply_ != reply) {
        reply->deleteLater();
        return;
    }
    playback_reply_ = nullptr;

    const int status_code = reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();
    const QByteArray body = reply->readAll();
    const QByteArray retry_after = reply->rawHeader("Retry-After");
    const QString network_error = reply->error() == QNetworkReply::NoError ? QString{} : reply->errorString();
    reply->deleteLater();

    if (!running_) {
        return;
    }

    if (status_code == 200) {
        TrackState state;
        QString parse_error;
        if (!parse_playback(body, &state, &parse_error)) {
            report_error(parse_error);
            schedule_failure_backoff();
            return;
        }

        consecutive_failures_ = 0;
        const bool playing = state.status == PlaybackStatus::playing;
        publish(std::move(state));
        schedule_poll(playing ? playing_poll_ms : idle_poll_ms);
        return;
    }

    if (status_code == 204) {
        consecutive_failures_ = 0;
        publish_empty(PlaybackStatus::stopped);
        schedule_poll(idle_poll_ms);
        return;
    }

    if (status_code == 401) {
        auth_.force_refresh_access_token();
        return;
    }

    if (status_code == 429) {
        bool valid_retry = false;
        const int seconds = retry_after.toInt(&valid_retry);
        const int bounded_seconds = std::clamp(valid_retry ? seconds : 10, 1, 3'600);
        report_error(QStringLiteral("Spotify rate limit reached; waiting %1 seconds").arg(bounded_seconds));
        schedule_poll(bounded_seconds * 1'000);
        return;
    }

    report_error(network_error.isEmpty()
                     ? QStringLiteral("Spotify playback request failed with HTTP %1").arg(status_code)
                     : network_error);
    schedule_failure_backoff();
}

void SpotifyPlaybackProvider::publish(TrackState state)
{
    if (on_state_) {
        on_state_(state);
    }
}

void SpotifyPlaybackProvider::publish_empty(PlaybackStatus status)
{
    TrackState state;
    state.status = status;
    state.observed_at = std::chrono::steady_clock::now();
    publish(std::move(state));
}

void SpotifyPlaybackProvider::report_error(const QString& message)
{
    if (on_error_) {
        on_error_(to_utf8(message));
    }
}

void SpotifyPlaybackProvider::schedule_failure_backoff()
{
    ++consecutive_failures_;
    const int exponent = std::min(consecutive_failures_ - 1, 5);
    const int delay = std::min(2'000 * (1 << exponent), maximum_failure_backoff_ms);
    schedule_poll(delay);
}

bool SpotifyPlaybackProvider::parse_playback(const QByteArray& body, TrackState* state, QString* error)
{
    if (!state) {
        if (error) {
            *error = QStringLiteral("Playback destination was not provided");
        }
        return false;
    }

    QJsonParseError parse_error;
    const QJsonDocument document = QJsonDocument::fromJson(body, &parse_error);
    if (parse_error.error != QJsonParseError::NoError || !document.isObject()) {
        if (error) {
            *error = QStringLiteral("Spotify returned invalid playback data: %1").arg(parse_error.errorString());
        }
        return false;
    }

    const QJsonObject root = document.object();
    const QJsonObject item = root.value(QStringLiteral("item")).toObject();
    const QString reported_type = root.value(QStringLiteral("currently_playing_type")).toString();
    const QString item_type = item.value(QStringLiteral("type")).toString(reported_type);

    TrackState parsed;
    parsed.observed_at = std::chrono::steady_clock::now();
    parsed.provider_timestamp_ms = root.value(QStringLiteral("timestamp")).toInteger();
    parsed.progress_ms = root.value(QStringLiteral("progress_ms")).toInteger();
    parsed.status = root.value(QStringLiteral("is_playing")).toBool() ? PlaybackStatus::playing
                                                                      : PlaybackStatus::paused;

    if (reported_type == QStringLiteral("ad")) {
        parsed.track_id = "spotify:advertisement";
        parsed.title = "Advertisement";
        parsed.content_type = ContentType::advertisement;
        *state = std::move(parsed);
        return true;
    }

    if (item.isEmpty()) {
        parsed.status = PlaybackStatus::stopped;
        *state = std::move(parsed);
        return true;
    }

    const QString title = item.value(QStringLiteral("name")).toString().trimmed();
    const QString item_id = item.value(QStringLiteral("id")).toString();
    const QString item_uri = item.value(QStringLiteral("uri")).toString();
    parsed.track_id = to_utf8(!item_id.isEmpty() ? item_id : item_uri);
    parsed.title = to_utf8(title);
    parsed.duration_ms = item.value(QStringLiteral("duration_ms")).toInteger();
    parsed.provider_url = to_utf8(external_spotify_url(item));
    parsed.explicit_content = item.value(QStringLiteral("explicit")).toBool();
    parsed.is_local = item.value(QStringLiteral("is_local")).toBool();

    if (item_type == QStringLiteral("track")) {
        parsed.content_type = ContentType::track;
        parsed.artists = to_utf8(joined_artist_names(item.value(QStringLiteral("artists")).toArray()));
        const QJsonObject album = item.value(QStringLiteral("album")).toObject();
        parsed.album = to_utf8(album.value(QStringLiteral("name")).toString());
        const QString artwork_key = QStringLiteral("album:") +
                                    album.value(QStringLiteral("id")).toString(item_id);
        parsed.artwork = choose_artwork(album.value(QStringLiteral("images")).toArray(), artwork_key);
    } else if (item_type == QStringLiteral("episode")) {
        parsed.content_type = ContentType::episode;
        const QJsonObject show = item.value(QStringLiteral("show")).toObject();
        const QString show_name = show.value(QStringLiteral("name")).toString();
        parsed.artists = to_utf8(show_name);
        parsed.album = to_utf8(show_name);
        QJsonArray images = item.value(QStringLiteral("images")).toArray();
        if (images.isEmpty()) {
            images = show.value(QStringLiteral("images")).toArray();
        }
        parsed.artwork = choose_artwork(images, QStringLiteral("episode:") + item_id);
    } else {
        parsed.content_type = ContentType::unknown;
        parsed.artwork = choose_artwork(item.value(QStringLiteral("images")).toArray(),
                                        QStringLiteral("item:") + item_id);
    }

    if (parsed.track_id.empty()) {
        parsed.track_id = "spotify:local:" + parsed.title + ":" + parsed.artists;
    }
    *state = std::move(parsed);
    return true;
}

} // namespace now_playing
