#include "card-renderer.hpp"

#include <QFontMetricsF>
#include <QLinearGradient>
#include <QPainter>
#include <QPainterPath>
#include <QRectF>

#include <algorithm>
#include <cmath>

namespace now_playing {
namespace {

constexpr double pi = 3.14159265358979323846;

Qt::Alignment qt_alignment(TextAlignment alignment)
{
    switch (alignment) {
    case TextAlignment::center:
        return Qt::AlignHCenter;
    case TextAlignment::right:
        return Qt::AlignRight;
    case TextAlignment::left:
    default:
        return Qt::AlignLeft;
    }
}

QString display_title(const TrackState& state)
{
    if (!state.title.empty()) {
        return QString::fromStdString(state.title);
    }
    if (state.status == PlaybackStatus::unavailable) {
        return QStringLiteral("Spotify not connected");
    }
    return QStringLiteral("Nothing playing");
}

QString status_text(PlaybackStatus status)
{
    switch (status) {
    case PlaybackStatus::playing:
        return QStringLiteral("PLAYING");
    case PlaybackStatus::paused:
        return QStringLiteral("PAUSED");
    case PlaybackStatus::stopped:
        return QStringLiteral("STOPPED");
    case PlaybackStatus::unavailable:
    default:
        return QStringLiteral("OFFLINE");
    }
}

QString format_time(std::int64_t milliseconds)
{
    const std::int64_t total_seconds = std::max<std::int64_t>(0, milliseconds / 1'000);
    const std::int64_t hours = total_seconds / 3'600;
    const std::int64_t minutes = (total_seconds % 3'600) / 60;
    const std::int64_t seconds = total_seconds % 60;
    if (hours > 0) {
        return QStringLiteral("%1:%2:%3")
            .arg(hours)
            .arg(minutes, 2, 10, QLatin1Char('0'))
            .arg(seconds, 2, 10, QLatin1Char('0'));
    }
    return QStringLiteral("%1:%2").arg(minutes).arg(seconds, 2, 10, QLatin1Char('0'));
}

QFont sized_font(const RenderConfig& config, int pixel_size, bool bold)
{
    QFont font = config.font;
    font.setPixelSize(pixel_size);
    font.setBold(bold || font.bold());
    return font;
}

void draw_line(QPainter& painter, const QString& text, const QFont& font, const QColor& color,
               const QRectF& bounds, TextAlignment alignment, OverflowMode overflow,
               double marquee_seconds, double marquee_speed)
{
    if (text.isEmpty() || bounds.width() <= 0.0 || bounds.height() <= 0.0) {
        return;
    }

    painter.save();
    painter.setFont(font);
    painter.setPen(color);
    painter.setClipRect(bounds);

    const QFontMetricsF metrics(font);
    const double text_width = metrics.horizontalAdvance(text);
    const double baseline = bounds.top() + (bounds.height() - metrics.height()) * 0.5 + metrics.ascent();
    const int single_line_flags = static_cast<int>(qt_alignment(alignment)) |
                                  static_cast<int>(Qt::AlignVCenter) |
                                  static_cast<int>(Qt::TextSingleLine);
    if (text_width <= bounds.width()) {
        painter.drawText(bounds, single_line_flags, text);
    } else if (overflow == OverflowMode::ellipsis) {
        const QString elided = metrics.elidedText(text, Qt::ElideRight,
                                                   static_cast<int>(bounds.width()));
        painter.drawText(bounds, single_line_flags, elided);
    } else {
        const double gap = std::max(48.0, bounds.height() * 1.6);
        const double cycle = text_width + gap;
        const double offset = std::fmod(std::max(0.0, marquee_seconds) * marquee_speed, cycle);
        const double first_x = bounds.left() - offset;
        painter.drawText(QPointF(first_x, baseline), text);
        painter.drawText(QPointF(first_x + cycle, baseline), text);
    }
    painter.restore();
}

QRectF contained_rect(const QSize& source, const QRectF& destination)
{
    if (!source.isValid() || destination.isEmpty()) {
        return {};
    }
    const double scale = std::min(destination.width() / source.width(),
                                  destination.height() / source.height());
    const QSizeF size(source.width() * scale, source.height() * scale);
    return QRectF(destination.center().x() - size.width() * 0.5,
                  destination.center().y() - size.height() * 0.5, size.width(), size.height());
}

void draw_artwork(QPainter& painter, const QImage& artwork, const QRectF& bounds, int radius,
                  const QColor& accent)
{
    QPainterPath path;
    path.addRoundedRect(bounds, radius, radius);
    painter.save();
    painter.setClipPath(path);
    if (!artwork.isNull()) {
        const QRectF target = contained_rect(artwork.size(), bounds);
        painter.drawImage(target, artwork, artwork.rect());
    } else {
        QColor first = accent;
        first.setAlpha(150);
        QColor second = accent.lighter(145);
        second.setAlpha(90);
        QLinearGradient placeholder(bounds.topLeft(), bounds.bottomRight());
        placeholder.setColorAt(0.0, first);
        placeholder.setColorAt(1.0, second);
        painter.fillRect(bounds, placeholder);
        QFont note_font(QStringLiteral("Segoe UI Symbol"));
        note_font.setPixelSize(static_cast<int>(bounds.height() * 0.42));
        note_font.setBold(true);
        painter.setFont(note_font);
        painter.setPen(QColor(255, 255, 255, 190));
        painter.drawText(bounds, Qt::AlignCenter, QStringLiteral("♪"));
    }
    painter.restore();
}

double eased(double value)
{
    const double t = std::clamp(value, 0.0, 1.0);
    return 1.0 - std::pow(1.0 - t, 3.0);
}

} // namespace

QImage CardRenderer::render(const TrackState& state, const QImage& artwork,
                            const RenderConfig& config, double animation_progress,
                            double marquee_seconds)
{
    const int width = std::max(1, static_cast<int>(config.width));
    const int height = std::max(1, static_cast<int>(config.height));
    QImage canvas(width, height, QImage::Format_ARGB32);
    canvas.fill(Qt::transparent);

    const bool hidden = (config.hide_when_idle && !state.has_content()) ||
                        (config.hide_when_paused && state.status == PlaybackStatus::paused);
    if (hidden) {
        return canvas;
    }

    QPainter painter(&canvas);
    painter.setRenderHints(QPainter::Antialiasing | QPainter::TextAntialiasing |
                           QPainter::SmoothPixmapTransform);

    const double entrance = config.transition == TransitionStyle::none ? 1.0
                                                                       : eased(animation_progress);
    painter.setOpacity(entrance);
    if (config.transition == TransitionStyle::slide_up) {
        painter.translate(0.0, (1.0 - entrance) * height * 0.16);
    } else if (config.transition == TransitionStyle::slide_left) {
        painter.translate((1.0 - entrance) * width * 0.10, 0.0);
    }

    const QRectF card(0.5, 0.5, width - 1.0, height - 1.0);
    QPainterPath card_path;
    card_path.addRoundedRect(card, config.corner_radius, config.corner_radius);

    if (config.gradient_enabled) {
        const double radians = config.gradient_angle * pi / 180.0;
        const QPointF direction(std::cos(radians), std::sin(radians));
        const double radius = std::hypot(card.width(), card.height()) * 0.5;
        const QPointF center = card.center();
        QLinearGradient gradient(center - direction * radius, center + direction * radius);
        gradient.setColorAt(0.0, config.background_start);
        gradient.setColorAt(1.0, config.background_end);
        painter.fillPath(card_path, gradient);
    } else {
        painter.fillPath(card_path, config.background_start);
    }

    if (config.border_width > 0 && config.border_color.alpha() > 0) {
        QPen border(config.border_color, config.border_width);
        border.setJoinStyle(Qt::RoundJoin);
        painter.setPen(border);
        painter.setBrush(Qt::NoBrush);
        const double inset = config.border_width * 0.5;
        painter.drawRoundedRect(card.adjusted(inset, inset, -inset, -inset),
                                std::max(0, config.corner_radius - config.border_width / 2),
                                std::max(0, config.corner_radius - config.border_width / 2));
    }

    const int padding = std::clamp(config.padding, 0, std::max(0, height / 3));
    QRectF content(padding, padding, std::max(1, width - padding * 2),
                   std::max(1, height - padding * 2));

    if (config.show_artwork) {
        const double artwork_size = std::max(
            1.0, std::min<double>(config.artwork_size, std::min(content.height(), content.width() * 0.45)));
        QRectF artwork_bounds;
        if (config.artwork_side == ArtworkSide::right) {
            artwork_bounds = QRectF(content.right() - artwork_size, content.top(), artwork_size,
                                    artwork_size);
            content.setRight(artwork_bounds.left() - padding);
        } else {
            artwork_bounds = QRectF(content.left(), content.top(), artwork_size, artwork_size);
            content.setLeft(artwork_bounds.right() + padding);
        }
        draw_artwork(painter, artwork, artwork_bounds, config.artwork_corner_radius,
                     config.progress_color);
    }

    const int progress_height = std::max(1, config.progress_height);
    const int time_height = config.show_time || config.show_status ? 19 : 0;
    const int progress_area_height = config.show_progress ? progress_height + 8 + time_height : 0;
    QRectF text_area = content;
    text_area.setBottom(std::max(text_area.top(), content.bottom() - progress_area_height));

    const QFont title_font = sized_font(config, config.title_size, true);
    const QFont artist_font = sized_font(config, config.artist_size, false);
    const QFont album_font = sized_font(config, config.album_size, false);
    const double title_height = QFontMetricsF(title_font).height() + 2.0;
    const double artist_height = QFontMetricsF(artist_font).height() + 2.0;
    const double album_height = config.show_album && !state.album.empty()
                                    ? QFontMetricsF(album_font).height() + 2.0
                                    : 0.0;
    const double text_gap = std::max(2.0, height * 0.015);
    const double block_height = title_height + artist_height + album_height +
                                text_gap * (album_height > 0.0 ? 2.0 : 1.0);
    double y = text_area.top() + std::max(0.0, (text_area.height() - block_height) * 0.5);

    draw_line(painter, display_title(state), title_font, config.title_color,
              QRectF(text_area.left(), y, text_area.width(), title_height), config.text_alignment,
              config.overflow_mode, marquee_seconds, config.marquee_speed);
    y += title_height + text_gap;

    const QString artist = state.artists.empty() && !state.has_content()
                               ? QStringLiteral("Connect Spotify from the OBS Tools menu")
                               : QString::fromStdString(state.artists);
    draw_line(painter, artist, artist_font, config.artist_color,
              QRectF(text_area.left(), y, text_area.width(), artist_height), config.text_alignment,
              config.overflow_mode, marquee_seconds, config.marquee_speed);
    y += artist_height + text_gap;

    if (album_height > 0.0) {
        draw_line(painter, QString::fromStdString(state.album), album_font, config.album_color,
                  QRectF(text_area.left(), y, text_area.width(), album_height), config.text_alignment,
                  config.overflow_mode, marquee_seconds, config.marquee_speed);
    }

    if (config.show_progress) {
        const double bar_y = content.bottom() - progress_height;
        const QRectF bar(content.left(), bar_y, content.width(), progress_height);
        QPainterPath background_path;
        background_path.addRoundedRect(bar, progress_height * 0.5, progress_height * 0.5);
        painter.fillPath(background_path, config.progress_background);

        const double ratio = std::clamp(state.progress_ratio(), 0.0, 1.0);
        if (ratio > 0.0) {
            QRectF fill = bar;
            fill.setWidth(std::max<double>(progress_height, bar.width() * ratio));
            QPainterPath fill_path;
            fill_path.addRoundedRect(fill, progress_height * 0.5, progress_height * 0.5);
            painter.fillPath(fill_path, config.progress_color);
        }

        if (time_height > 0) {
            const QFont time_font = sized_font(config, std::max(10, config.album_size - 2), false);
            painter.setFont(time_font);
            painter.setPen(config.album_color);
            const QRectF time_bounds(content.left(), bar.top() - time_height - 5, content.width(),
                                     time_height);
            if (config.show_time) {
                painter.drawText(time_bounds, Qt::AlignLeft | Qt::AlignVCenter,
                                 format_time(state.estimated_progress_ms()));
                painter.drawText(time_bounds, Qt::AlignRight | Qt::AlignVCenter,
                                 format_time(state.duration_ms));
            }
            if (config.show_status) {
                painter.drawText(time_bounds, Qt::AlignCenter | Qt::AlignVCenter,
                                 status_text(state.status));
            }
        }
    }

    painter.end();
    return canvas;
}

} // namespace now_playing
