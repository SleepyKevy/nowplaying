#pragma once

#include <QColor>
#include <QFont>

#include <cstdint>
#include <string>

namespace now_playing {

enum class ArtworkSide {
    left,
    right,
};

enum class TextAlignment {
    left,
    center,
    right,
};

enum class OverflowMode {
    ellipsis,
    marquee,
};

enum class TransitionStyle {
    none,
    fade,
    slide_up,
    slide_left,
};

struct RenderConfig {
    std::uint32_t width = 700;
    std::uint32_t height = 180;
    int padding = 18;
    int corner_radius = 22;
    int border_width = 1;

    bool gradient_enabled = true;
    QColor background_start{18, 23, 42, 242};
    QColor background_end{68, 35, 115, 242};
    double gradient_angle = 18.0;
    QColor border_color{255, 255, 255, 34};

    bool show_artwork = true;
    ArtworkSide artwork_side = ArtworkSide::left;
    int artwork_size = 144;
    int artwork_corner_radius = 16;

    QFont font{QStringLiteral("Segoe UI")};
    int title_size = 28;
    int artist_size = 20;
    int album_size = 16;
    QColor title_color{255, 255, 255, 255};
    QColor artist_color{225, 228, 238, 255};
    QColor album_color{174, 180, 199, 255};
    TextAlignment text_alignment = TextAlignment::left;
    bool show_album = true;
    OverflowMode overflow_mode = OverflowMode::ellipsis;
    double marquee_speed = 55.0;

    bool show_progress = true;
    bool show_time = true;
    bool show_status = true;
    int progress_height = 6;
    QColor progress_color{167, 102, 255, 255};
    QColor progress_background{255, 255, 255, 46};

    bool hide_when_idle = true;
    bool hide_when_paused = false;
    bool preview_mode = false;
    TransitionStyle transition = TransitionStyle::fade;
    int transition_duration_ms = 350;
};

} // namespace now_playing
