#pragma once

#include "../core/track-state.hpp"
#include "render-config.hpp"

#include <QImage>

namespace now_playing {

class CardRenderer final {
public:
    [[nodiscard]] static QImage render(const TrackState& state, const QImage& artwork,
                                       const RenderConfig& config, double animation_progress,
                                       double marquee_seconds);
};

} // namespace now_playing
