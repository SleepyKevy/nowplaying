#pragma once

#include "track-state.hpp"

#include <cstdint>
#include <mutex>
#include <shared_mutex>
#include <utility>

namespace now_playing {

class PlaybackStateStore {
public:
    void update(TrackState state)
    {
        std::unique_lock lock(mutex_);
        state_ = std::move(state);
        ++revision_;
    }

    [[nodiscard]] TrackState snapshot() const
    {
        std::shared_lock lock(mutex_);
        return state_;
    }

    [[nodiscard]] std::uint64_t revision() const
    {
        std::shared_lock lock(mutex_);
        return revision_;
    }

private:
    mutable std::shared_mutex mutex_;
    TrackState state_;
    std::uint64_t revision_ = 0;
};

} // namespace now_playing
