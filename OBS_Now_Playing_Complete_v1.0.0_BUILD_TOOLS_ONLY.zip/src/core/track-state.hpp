#pragma once

#include <chrono>
#include <cstdint>
#include <string>

namespace now_playing {

enum class PlaybackStatus {
    unavailable,
    stopped,
    paused,
    playing,
};

enum class ContentType {
    unknown,
    track,
    episode,
    advertisement,
};

struct ArtworkReference {
    std::string url;
    std::string cache_key;
    std::string local_path;
    std::uint32_t width = 0;
    std::uint32_t height = 0;
};

struct TrackState {
    std::string track_id;
    std::string title;
    std::string artists;
    std::string album;
    std::string provider_url;
    ArtworkReference artwork;

    std::int64_t duration_ms = 0;
    std::int64_t progress_ms = 0;
    std::int64_t provider_timestamp_ms = 0;
    PlaybackStatus status = PlaybackStatus::unavailable;
    ContentType content_type = ContentType::unknown;
    bool explicit_content = false;
    bool is_local = false;
    std::chrono::steady_clock::time_point observed_at{};

    [[nodiscard]] bool has_track() const noexcept
    {
        return content_type == ContentType::track && !track_id.empty() && !title.empty();
    }

    [[nodiscard]] bool has_content() const noexcept
    {
        return !track_id.empty() && !title.empty() && status != PlaybackStatus::unavailable &&
               status != PlaybackStatus::stopped;
    }

    [[nodiscard]] std::int64_t estimated_progress_ms(
        std::chrono::steady_clock::time_point now = std::chrono::steady_clock::now()) const noexcept
    {
        std::int64_t estimate = progress_ms;
        if (status == PlaybackStatus::playing && observed_at != std::chrono::steady_clock::time_point{}) {
            estimate += std::chrono::duration_cast<std::chrono::milliseconds>(now - observed_at).count();
        }

        if (estimate < 0) {
            return 0;
        }
        if (duration_ms > 0 && estimate > duration_ms) {
            return duration_ms;
        }
        return estimate;
    }

    [[nodiscard]] double progress_ratio(
        std::chrono::steady_clock::time_point now = std::chrono::steady_clock::now()) const noexcept
    {
        if (duration_ms <= 0) {
            return 0.0;
        }

        return static_cast<double>(estimated_progress_ms(now)) / static_cast<double>(duration_ms);
    }
};

} // namespace now_playing
