#include "now-playing-source.hpp"

#include "../core/playback-state-store.hpp"
#include "../render/card-renderer.hpp"
#include "../render/render-config.hpp"

#include <obs-module.h>

#include <QImage>
#include <QImageReader>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <limits>
#include <mutex>
#include <new>
#include <string>

namespace {

constexpr std::uint32_t default_width = 700;
constexpr std::uint32_t default_height = 180;
constexpr double progress_refresh_seconds = 0.10;
constexpr double animation_refresh_seconds = 1.0 / 60.0;

std::atomic<now_playing::PlaybackStateStore*> playback_store{nullptr};

constexpr std::uint32_t obs_rgba(std::uint8_t red, std::uint8_t green, std::uint8_t blue,
                                 std::uint8_t alpha = 255)
{
    return static_cast<std::uint32_t>(red) | (static_cast<std::uint32_t>(green) << 8U) |
           (static_cast<std::uint32_t>(blue) << 16U) |
           (static_cast<std::uint32_t>(alpha) << 24U);
}

QColor to_qcolor(std::uint32_t color)
{
    return QColor(static_cast<int>(color & 0xffU), static_cast<int>((color >> 8U) & 0xffU),
                  static_cast<int>((color >> 16U) & 0xffU),
                  static_cast<int>((color >> 24U) & 0xffU));
}

struct NowPlayingSourceContext {
    obs_source_t* source = nullptr;
    std::atomic<std::uint32_t> width{default_width};
    std::atomic<std::uint32_t> height{default_height};
    std::mutex config_mutex;
    now_playing::RenderConfig config;
    std::atomic<std::uint64_t> config_generation{1};

    std::uint64_t rendered_config_generation = 0;
    std::uint64_t playback_revision = std::numeric_limits<std::uint64_t>::max();
    now_playing::TrackState playback;
    std::string transition_key;
    std::string loaded_artwork_path;
    QImage artwork;
    double transition_elapsed_seconds = 1.0;
    double marquee_elapsed_seconds = 0.0;
    double refresh_elapsed_seconds = 0.0;
    bool preview_active = false;

    gs_texture_t* texture = nullptr;
    std::uint32_t texture_width = 0;
    std::uint32_t texture_height = 0;
    bool redraw_requested = true;
};

const char* source_name(void*)
{
    return obs_module_text("NowPlayingSource.Name");
}

now_playing::ArtworkSide parse_artwork_side(const char* value)
{
    return value && std::string(value) == "right" ? now_playing::ArtworkSide::right
                                                   : now_playing::ArtworkSide::left;
}

now_playing::TextAlignment parse_text_alignment(const char* value)
{
    if (value && std::string(value) == "center") {
        return now_playing::TextAlignment::center;
    }
    if (value && std::string(value) == "right") {
        return now_playing::TextAlignment::right;
    }
    return now_playing::TextAlignment::left;
}

now_playing::OverflowMode parse_overflow(const char* value)
{
    return value && std::string(value) == "marquee" ? now_playing::OverflowMode::marquee
                                                     : now_playing::OverflowMode::ellipsis;
}

now_playing::TransitionStyle parse_transition(const char* value)
{
    if (value && std::string(value) == "fade") {
        return now_playing::TransitionStyle::fade;
    }
    if (value && std::string(value) == "slide_up") {
        return now_playing::TransitionStyle::slide_up;
    }
    if (value && std::string(value) == "slide_left") {
        return now_playing::TransitionStyle::slide_left;
    }
    return now_playing::TransitionStyle::none;
}

QFont read_font(obs_data_t* settings)
{
    QFont font(QStringLiteral("Segoe UI"));
    obs_data_t* object = obs_data_get_obj(settings, "font");
    if (!object) {
        return font;
    }

    const QString face = QString::fromUtf8(obs_data_get_string(object, "face"));
    if (!face.trimmed().isEmpty()) {
        font.setFamily(face);
    }
    const std::int64_t flags = obs_data_get_int(object, "flags");
    font.setBold((flags & OBS_FONT_BOLD) != 0);
    font.setItalic((flags & OBS_FONT_ITALIC) != 0);
    font.setUnderline((flags & OBS_FONT_UNDERLINE) != 0);
    font.setStrikeOut((flags & OBS_FONT_STRIKEOUT) != 0);
    obs_data_release(object);
    return font;
}

now_playing::RenderConfig read_config(obs_data_t* settings)
{
    now_playing::RenderConfig config;
    config.width = static_cast<std::uint32_t>(
        std::clamp<std::int64_t>(obs_data_get_int(settings, "canvas_width"), 320, 3840));
    config.height = static_cast<std::uint32_t>(
        std::clamp<std::int64_t>(obs_data_get_int(settings, "canvas_height"), 80, 2160));
    config.padding = static_cast<int>(obs_data_get_int(settings, "padding"));
    config.corner_radius = static_cast<int>(obs_data_get_int(settings, "corner_radius"));
    config.border_width = static_cast<int>(obs_data_get_int(settings, "border_width"));

    config.gradient_enabled = obs_data_get_bool(settings, "gradient_enabled");
    config.background_start =
        to_qcolor(static_cast<std::uint32_t>(obs_data_get_int(settings, "background_start")));
    config.background_end =
        to_qcolor(static_cast<std::uint32_t>(obs_data_get_int(settings, "background_end")));
    config.gradient_angle = obs_data_get_double(settings, "gradient_angle");
    config.border_color =
        to_qcolor(static_cast<std::uint32_t>(obs_data_get_int(settings, "border_color")));

    config.show_artwork = obs_data_get_bool(settings, "show_artwork");
    config.artwork_side = parse_artwork_side(obs_data_get_string(settings, "artwork_side"));
    config.artwork_size = static_cast<int>(obs_data_get_int(settings, "artwork_size"));
    config.artwork_corner_radius =
        static_cast<int>(obs_data_get_int(settings, "artwork_corner_radius"));

    config.font = read_font(settings);
    config.title_size = static_cast<int>(obs_data_get_int(settings, "title_size"));
    config.artist_size = static_cast<int>(obs_data_get_int(settings, "artist_size"));
    config.album_size = static_cast<int>(obs_data_get_int(settings, "album_size"));
    config.title_color =
        to_qcolor(static_cast<std::uint32_t>(obs_data_get_int(settings, "title_color")));
    config.artist_color =
        to_qcolor(static_cast<std::uint32_t>(obs_data_get_int(settings, "artist_color")));
    config.album_color =
        to_qcolor(static_cast<std::uint32_t>(obs_data_get_int(settings, "album_color")));
    config.text_alignment = parse_text_alignment(obs_data_get_string(settings, "text_alignment"));
    config.show_album = obs_data_get_bool(settings, "show_album");
    config.overflow_mode = parse_overflow(obs_data_get_string(settings, "overflow_mode"));
    config.marquee_speed = obs_data_get_double(settings, "marquee_speed");

    config.show_progress = obs_data_get_bool(settings, "show_progress");
    config.show_time = obs_data_get_bool(settings, "show_time");
    config.show_status = obs_data_get_bool(settings, "show_status");
    config.progress_height = static_cast<int>(obs_data_get_int(settings, "progress_height"));
    config.progress_color =
        to_qcolor(static_cast<std::uint32_t>(obs_data_get_int(settings, "progress_color")));
    config.progress_background =
        to_qcolor(static_cast<std::uint32_t>(obs_data_get_int(settings, "progress_background")));

    config.hide_when_idle = obs_data_get_bool(settings, "hide_when_idle");
    config.hide_when_paused = obs_data_get_bool(settings, "hide_when_paused");
    config.preview_mode = obs_data_get_bool(settings, "preview_mode");
    config.transition = parse_transition(obs_data_get_string(settings, "transition"));
    config.transition_duration_ms =
        static_cast<int>(obs_data_get_int(settings, "transition_duration"));
    return config;
}

void source_update(void* data, obs_data_t* settings)
{
    auto* context = static_cast<NowPlayingSourceContext*>(data);
    if (!context || !settings) {
        return;
    }

    now_playing::RenderConfig config = read_config(settings);
    context->width.store(config.width, std::memory_order_relaxed);
    context->height.store(config.height, std::memory_order_relaxed);
    {
        std::lock_guard lock(context->config_mutex);
        context->config = std::move(config);
    }
    context->config_generation.fetch_add(1, std::memory_order_release);
}

void* source_create(obs_data_t* settings, obs_source_t* source)
{
    auto* context = new (std::nothrow) NowPlayingSourceContext{};
    if (!context) {
        blog(LOG_ERROR, "[obs-now-playing] Unable to allocate the source context");
        return nullptr;
    }

    context->source = source;
    source_update(context, settings);
    return context;
}

void source_destroy(void* data)
{
    auto* context = static_cast<NowPlayingSourceContext*>(data);
    if (!context) {
        return;
    }
    if (context->texture) {
        obs_enter_graphics();
        gs_texture_destroy(context->texture);
        obs_leave_graphics();
        context->texture = nullptr;
    }
    delete context;
}

std::uint32_t source_width(void* data)
{
    const auto* context = static_cast<const NowPlayingSourceContext*>(data);
    return context ? context->width.load(std::memory_order_relaxed) : default_width;
}

std::uint32_t source_height(void* data)
{
    const auto* context = static_cast<const NowPlayingSourceContext*>(data);
    return context ? context->height.load(std::memory_order_relaxed) : default_height;
}

void add_list_item(obs_property_t* property, const char* label_key, const char* value)
{
    obs_property_list_add_string(property, obs_module_text(label_key), value);
}

obs_properties_t* source_properties(void*)
{
    obs_properties_t* properties = obs_properties_create();

    obs_properties_t* layout = obs_properties_create();
    obs_properties_add_int(layout, "canvas_width", obs_module_text("NowPlayingSource.CanvasWidth"),
                           320, 3840, 1);
    obs_properties_add_int(layout, "canvas_height", obs_module_text("NowPlayingSource.CanvasHeight"),
                           80, 2160, 1);
    obs_properties_add_int_slider(layout, "padding", obs_module_text("NowPlayingSource.Padding"), 0,
                                  120, 1);
    obs_properties_add_int_slider(layout, "corner_radius",
                                  obs_module_text("NowPlayingSource.CornerRadius"), 0, 100, 1);
    obs_properties_add_int_slider(layout, "border_width",
                                  obs_module_text("NowPlayingSource.BorderWidth"), 0, 12, 1);
    obs_properties_add_group(properties, "layout_group", obs_module_text("NowPlayingSource.Layout"),
                             OBS_GROUP_NORMAL, layout);

    obs_properties_t* background = obs_properties_create();
    obs_properties_add_bool(background, "gradient_enabled",
                            obs_module_text("NowPlayingSource.GradientEnabled"));
    obs_properties_add_color_alpha(background, "background_start",
                                   obs_module_text("NowPlayingSource.BackgroundStart"));
    obs_properties_add_color_alpha(background, "background_end",
                                   obs_module_text("NowPlayingSource.BackgroundEnd"));
    obs_properties_add_float_slider(background, "gradient_angle",
                                    obs_module_text("NowPlayingSource.GradientAngle"), 0.0, 360.0,
                                    1.0);
    obs_properties_add_color_alpha(background, "border_color",
                                   obs_module_text("NowPlayingSource.BorderColor"));
    obs_properties_add_group(properties, "background_group",
                             obs_module_text("NowPlayingSource.Background"), OBS_GROUP_NORMAL,
                             background);

    obs_properties_t* artwork = obs_properties_create();
    obs_properties_add_bool(artwork, "show_artwork",
                            obs_module_text("NowPlayingSource.ShowArtwork"));
    obs_property_t* artwork_side = obs_properties_add_list(
        artwork, "artwork_side", obs_module_text("NowPlayingSource.ArtworkSide"),
        OBS_COMBO_TYPE_LIST, OBS_COMBO_FORMAT_STRING);
    add_list_item(artwork_side, "NowPlayingSource.Left", "left");
    add_list_item(artwork_side, "NowPlayingSource.Right", "right");
    obs_properties_add_int_slider(artwork, "artwork_size",
                                  obs_module_text("NowPlayingSource.ArtworkSize"), 48, 600, 1);
    obs_properties_add_int_slider(artwork, "artwork_corner_radius",
                                  obs_module_text("NowPlayingSource.ArtworkCornerRadius"), 0, 100,
                                  1);
    obs_properties_add_group(properties, "artwork_group",
                             obs_module_text("NowPlayingSource.Artwork"), OBS_GROUP_NORMAL, artwork);

    obs_properties_t* typography = obs_properties_create();
    obs_properties_add_font(typography, "font", obs_module_text("NowPlayingSource.Font"));
    obs_properties_add_int_slider(typography, "title_size",
                                  obs_module_text("NowPlayingSource.TitleSize"), 10, 120, 1);
    obs_properties_add_int_slider(typography, "artist_size",
                                  obs_module_text("NowPlayingSource.ArtistSize"), 8, 96, 1);
    obs_properties_add_int_slider(typography, "album_size",
                                  obs_module_text("NowPlayingSource.AlbumSize"), 8, 72, 1);
    obs_properties_add_color_alpha(typography, "title_color",
                                   obs_module_text("NowPlayingSource.TitleColor"));
    obs_properties_add_color_alpha(typography, "artist_color",
                                   obs_module_text("NowPlayingSource.ArtistColor"));
    obs_properties_add_color_alpha(typography, "album_color",
                                   obs_module_text("NowPlayingSource.AlbumColor"));
    obs_property_t* text_alignment = obs_properties_add_list(
        typography, "text_alignment", obs_module_text("NowPlayingSource.TextAlignment"),
        OBS_COMBO_TYPE_LIST, OBS_COMBO_FORMAT_STRING);
    add_list_item(text_alignment, "NowPlayingSource.Left", "left");
    add_list_item(text_alignment, "NowPlayingSource.Center", "center");
    add_list_item(text_alignment, "NowPlayingSource.Right", "right");
    obs_properties_add_bool(typography, "show_album",
                            obs_module_text("NowPlayingSource.ShowAlbum"));
    obs_property_t* overflow = obs_properties_add_list(
        typography, "overflow_mode", obs_module_text("NowPlayingSource.OverflowMode"),
        OBS_COMBO_TYPE_LIST, OBS_COMBO_FORMAT_STRING);
    add_list_item(overflow, "NowPlayingSource.Ellipsis", "ellipsis");
    add_list_item(overflow, "NowPlayingSource.Marquee", "marquee");
    obs_properties_add_float_slider(typography, "marquee_speed",
                                    obs_module_text("NowPlayingSource.MarqueeSpeed"), 10.0, 250.0,
                                    1.0);
    obs_properties_add_group(properties, "typography_group",
                             obs_module_text("NowPlayingSource.Typography"), OBS_GROUP_NORMAL,
                             typography);

    obs_properties_t* progress = obs_properties_create();
    obs_properties_add_bool(progress, "show_progress",
                            obs_module_text("NowPlayingSource.ShowProgress"));
    obs_properties_add_bool(progress, "show_time", obs_module_text("NowPlayingSource.ShowTime"));
    obs_properties_add_bool(progress, "show_status",
                            obs_module_text("NowPlayingSource.ShowStatus"));
    obs_properties_add_int_slider(progress, "progress_height",
                                  obs_module_text("NowPlayingSource.ProgressHeight"), 2, 30, 1);
    obs_properties_add_color_alpha(progress, "progress_color",
                                   obs_module_text("NowPlayingSource.ProgressColor"));
    obs_properties_add_color_alpha(progress, "progress_background",
                                   obs_module_text("NowPlayingSource.ProgressBackground"));
    obs_properties_add_group(properties, "progress_group",
                             obs_module_text("NowPlayingSource.Progress"), OBS_GROUP_NORMAL,
                             progress);

    obs_properties_t* behavior = obs_properties_create();
    obs_properties_add_bool(behavior, "hide_when_idle",
                            obs_module_text("NowPlayingSource.HideWhenIdle"));
    obs_properties_add_bool(behavior, "hide_when_paused",
                            obs_module_text("NowPlayingSource.HideWhenPaused"));
    obs_properties_add_bool(behavior, "preview_mode",
                            obs_module_text("NowPlayingSource.PreviewMode"));
    obs_property_t* transition = obs_properties_add_list(
        behavior, "transition", obs_module_text("NowPlayingSource.Transition"),
        OBS_COMBO_TYPE_LIST, OBS_COMBO_FORMAT_STRING);
    add_list_item(transition, "NowPlayingSource.None", "none");
    add_list_item(transition, "NowPlayingSource.Fade", "fade");
    add_list_item(transition, "NowPlayingSource.SlideUp", "slide_up");
    add_list_item(transition, "NowPlayingSource.SlideLeft", "slide_left");
    obs_properties_add_int_slider(behavior, "transition_duration",
                                  obs_module_text("NowPlayingSource.TransitionDuration"), 100, 2000,
                                  25);
    obs_properties_add_group(properties, "behavior_group",
                             obs_module_text("NowPlayingSource.Behavior"), OBS_GROUP_NORMAL,
                             behavior);

    obs_properties_add_text(properties, "connection_notice",
                            obs_module_text("NowPlayingSource.ConnectionNotice"), OBS_TEXT_INFO);
    return properties;
}

void source_defaults(obs_data_t* settings)
{
    obs_data_set_default_int(settings, "canvas_width", default_width);
    obs_data_set_default_int(settings, "canvas_height", default_height);
    obs_data_set_default_int(settings, "padding", 18);
    obs_data_set_default_int(settings, "corner_radius", 22);
    obs_data_set_default_int(settings, "border_width", 1);

    obs_data_set_default_bool(settings, "gradient_enabled", true);
    obs_data_set_default_int(settings, "background_start", obs_rgba(18, 23, 42, 242));
    obs_data_set_default_int(settings, "background_end", obs_rgba(68, 35, 115, 242));
    obs_data_set_default_double(settings, "gradient_angle", 18.0);
    obs_data_set_default_int(settings, "border_color", obs_rgba(255, 255, 255, 34));

    obs_data_set_default_bool(settings, "show_artwork", true);
    obs_data_set_default_string(settings, "artwork_side", "left");
    obs_data_set_default_int(settings, "artwork_size", 144);
    obs_data_set_default_int(settings, "artwork_corner_radius", 16);

    obs_data_t* font = obs_data_create();
    obs_data_set_string(font, "face", "Segoe UI");
    obs_data_set_int(font, "size", 28);
    obs_data_set_int(font, "flags", 0);
    obs_data_set_default_obj(settings, "font", font);
    obs_data_release(font);
    obs_data_set_default_int(settings, "title_size", 28);
    obs_data_set_default_int(settings, "artist_size", 20);
    obs_data_set_default_int(settings, "album_size", 16);
    obs_data_set_default_int(settings, "title_color", obs_rgba(255, 255, 255));
    obs_data_set_default_int(settings, "artist_color", obs_rgba(225, 228, 238));
    obs_data_set_default_int(settings, "album_color", obs_rgba(174, 180, 199));
    obs_data_set_default_string(settings, "text_alignment", "left");
    obs_data_set_default_bool(settings, "show_album", true);
    obs_data_set_default_string(settings, "overflow_mode", "ellipsis");
    obs_data_set_default_double(settings, "marquee_speed", 55.0);

    obs_data_set_default_bool(settings, "show_progress", true);
    obs_data_set_default_bool(settings, "show_time", true);
    obs_data_set_default_bool(settings, "show_status", true);
    obs_data_set_default_int(settings, "progress_height", 6);
    obs_data_set_default_int(settings, "progress_color", obs_rgba(167, 102, 255));
    obs_data_set_default_int(settings, "progress_background", obs_rgba(255, 255, 255, 46));

    obs_data_set_default_bool(settings, "hide_when_idle", true);
    obs_data_set_default_bool(settings, "hide_when_paused", false);
    obs_data_set_default_bool(settings, "preview_mode", false);
    obs_data_set_default_string(settings, "transition", "fade");
    obs_data_set_default_int(settings, "transition_duration", 350);
}

now_playing::TrackState sample_state(double elapsed_seconds)
{
    now_playing::TrackState state;
    state.track_id = "obs-now-playing:preview";
    state.title = "Midnight Drive";
    state.artists = "The Sleepy Sessions";
    state.album = "After Hours";
    state.duration_ms = 213'000;
    state.progress_ms = static_cast<std::int64_t>(
        std::fmod(74'000.0 + elapsed_seconds * 1'000.0, static_cast<double>(state.duration_ms)));
    state.status = now_playing::PlaybackStatus::playing;
    state.content_type = now_playing::ContentType::track;
    state.observed_at = std::chrono::steady_clock::now();
    return state;
}

void load_artwork_if_needed(NowPlayingSourceContext* context,
                            const now_playing::TrackState& playback)
{
    if (context->loaded_artwork_path == playback.artwork.local_path) {
        return;
    }
    context->loaded_artwork_path = playback.artwork.local_path;
    context->artwork = QImage{};
    if (context->loaded_artwork_path.empty()) {
        return;
    }

    QImageReader reader(QString::fromStdString(context->loaded_artwork_path));
    reader.setAutoDetectImageFormat(true);
    reader.setDecideFormatFromContent(true);
    reader.setAutoTransform(false);
    context->artwork = reader.read();
    if (context->artwork.isNull()) {
        blog(LOG_WARNING, "[obs-now-playing] Cached artwork could not be loaded by the renderer: %s",
             reader.errorString().toUtf8().constData());
    }
}

void upload_texture(NowPlayingSourceContext* context, const QImage& image)
{
    if (image.isNull()) {
        return;
    }
    const std::uint32_t width = static_cast<std::uint32_t>(image.width());
    const std::uint32_t height = static_cast<std::uint32_t>(image.height());
    const auto* pixels = reinterpret_cast<const std::uint8_t*>(image.constBits());

    obs_enter_graphics();
    if (!context->texture || context->texture_width != width || context->texture_height != height) {
        if (context->texture) {
            gs_texture_destroy(context->texture);
        }
        const std::uint8_t* planes[] = {pixels};
        context->texture = gs_texture_create(width, height, GS_BGRA, 1, planes, GS_DYNAMIC);
        context->texture_width = width;
        context->texture_height = height;
    } else {
        gs_texture_set_image(context->texture, pixels,
                             static_cast<std::uint32_t>(image.bytesPerLine()), false);
    }
    obs_leave_graphics();
}

void source_tick(void* data, float seconds)
{
    auto* context = static_cast<NowPlayingSourceContext*>(data);
    if (!context) {
        return;
    }

    now_playing::RenderConfig config;
    {
        std::lock_guard lock(context->config_mutex);
        config = context->config;
    }
    const std::uint64_t config_generation =
        context->config_generation.load(std::memory_order_acquire);
    if (context->rendered_config_generation != config_generation) {
        context->rendered_config_generation = config_generation;
        context->redraw_requested = true;
    }

    context->marquee_elapsed_seconds += std::max(0.0f, seconds);
    context->refresh_elapsed_seconds += std::max(0.0f, seconds);

    now_playing::TrackState latest;
    std::uint64_t revision = 0;
    if (now_playing::PlaybackStateStore* store = playback_store.load(std::memory_order_acquire)) {
        revision = store->revision();
        latest = store->snapshot();
    }
    if (config.preview_mode) {
        latest = sample_state(context->marquee_elapsed_seconds);
        revision = context->playback_revision;
    }

    if (revision != context->playback_revision || config.preview_mode || context->preview_active) {
        const std::string next_key = latest.track_id + ":" + std::to_string(static_cast<int>(latest.content_type));
        if (next_key != context->transition_key) {
            context->transition_key = next_key;
            context->transition_elapsed_seconds = 0.0;
            context->marquee_elapsed_seconds = 0.0;
        }
        context->playback = std::move(latest);
        context->playback_revision = revision;
        context->preview_active = config.preview_mode;
        load_artwork_if_needed(context, context->playback);
        context->redraw_requested = true;
    }

    const double transition_duration = std::max(0.001, config.transition_duration_ms / 1'000.0);
    if (context->transition_elapsed_seconds < transition_duration) {
        context->transition_elapsed_seconds += std::max(0.0f, seconds);
        if (context->refresh_elapsed_seconds >= animation_refresh_seconds) {
            context->redraw_requested = true;
        }
    }

    const bool progress_is_moving = context->playback.status == now_playing::PlaybackStatus::playing &&
                                    (config.show_progress || config.show_time);
    const bool marquee_is_moving = config.overflow_mode == now_playing::OverflowMode::marquee;
    if ((progress_is_moving && context->refresh_elapsed_seconds >= progress_refresh_seconds) ||
        (marquee_is_moving && context->refresh_elapsed_seconds >= animation_refresh_seconds)) {
        context->redraw_requested = true;
    }

    if (!context->redraw_requested) {
        return;
    }
    context->redraw_requested = false;
    context->refresh_elapsed_seconds = 0.0;
    const double animation_progress = std::clamp(context->transition_elapsed_seconds /
                                                     transition_duration,
                                                 0.0, 1.0);
    const QImage frame = now_playing::CardRenderer::render(
        context->playback, context->artwork, config, animation_progress,
        context->marquee_elapsed_seconds);
    upload_texture(context, frame);
}

void source_render(void* data, gs_effect_t*)
{
    auto* context = static_cast<NowPlayingSourceContext*>(data);
    if (!context || !context->texture) {
        return;
    }

    gs_effect_t* effect = obs_get_base_effect(OBS_EFFECT_DEFAULT);
    gs_technique_t* technique = gs_effect_get_technique(effect, "Draw");
    const bool previous_srgb = gs_framebuffer_srgb_enabled();
    gs_enable_framebuffer_srgb(true);
    gs_technique_begin(technique);
    gs_technique_begin_pass(technique, 0);
    gs_effect_set_texture_srgb(gs_effect_get_param_by_name(effect, "image"), context->texture);
    gs_draw_sprite(context->texture, 0, context->texture_width, context->texture_height);
    gs_technique_end_pass(technique);
    gs_technique_end(technique);
    gs_enable_framebuffer_srgb(previous_srgb);
}

obs_source_info make_source_info()
{
    obs_source_info info{};
    info.id = "obs_now_playing_source";
    info.type = OBS_SOURCE_TYPE_INPUT;
    info.output_flags = OBS_SOURCE_VIDEO | OBS_SOURCE_CUSTOM_DRAW;
    info.get_name = source_name;
    info.create = source_create;
    info.destroy = source_destroy;
    info.update = source_update;
    info.get_defaults = source_defaults;
    info.get_properties = source_properties;
    info.get_width = source_width;
    info.get_height = source_height;
    info.video_tick = source_tick;
    info.video_render = source_render;
    return info;
}

} // namespace

namespace now_playing {

void set_now_playing_playback_store(PlaybackStateStore* store) noexcept
{
    playback_store.store(store, std::memory_order_release);
}

} // namespace now_playing

obs_source_info now_playing_source_info = make_source_info();
