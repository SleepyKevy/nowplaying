#pragma once

#include <obs.h>

namespace now_playing {

class PlaybackStateStore;

void set_now_playing_playback_store(PlaybackStateStore* store) noexcept;

} // namespace now_playing

extern obs_source_info now_playing_source_info;
