#include "artwork-cache.hpp"

#include <obs-module.h>
#include <util/bmem.h>

#include <QBuffer>
#include <QCryptographicHash>
#include <QDateTime>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QImage>
#include <QImageReader>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QSaveFile>
#include <QStringList>
#include <QTimer>
#include <QUrl>
#include <QVariant>

#include <algorithm>
#include <utility>

namespace now_playing {
namespace {

constexpr qint64 maximum_download_bytes = 12 * 1024 * 1024;
constexpr qint64 maximum_cache_bytes = 150 * 1024 * 1024;
constexpr int maximum_cache_files = 250;
constexpr int maximum_image_dimension = 4'096;
constexpr qint64 maximum_image_pixels = 25'000'000;
constexpr int request_timeout_ms = 20'000;
constexpr qint64 failure_retry_delay_ms = 60'000;

QString plugin_cache_directory()
{
    char* path = obs_module_config_path("artwork-cache");
    if (!path) {
        return {};
    }

    const QString result = QString::fromUtf8(path);
    bfree(path);
    return result;
}

} // namespace

ArtworkCache::ArtworkCache(QObject* parent) : QObject(parent), cache_directory_(plugin_cache_directory())
{
    if (!cache_directory_.isEmpty()) {
        QDir().mkpath(cache_directory_);
    }
    network_.setRedirectPolicy(QNetworkRequest::NoLessSafeRedirectPolicy);
    enforce_limits();
}

ArtworkCache::~ArtworkCache()
{
    for (const QPointer<QNetworkReply>& reply : std::as_const(in_flight_)) {
        if (reply) {
            QObject::disconnect(reply.data(), nullptr, this, nullptr);
            reply->abort();
            reply->deleteLater();
        }
    }
    in_flight_.clear();
}

void ArtworkCache::request(const ArtworkReference& artwork)
{
    const QString cache_key = QString::fromStdString(artwork.cache_key);
    const QUrl url(QString::fromStdString(artwork.url));
    if (cache_key.isEmpty() || !url.isValid() || url.scheme() != QStringLiteral("https")) {
        emit artwork_failed(cache_key, QStringLiteral("Artwork URL is missing or is not HTTPS"));
        return;
    }
    if (cache_directory_.isEmpty() || !QDir().mkpath(cache_directory_)) {
        emit artwork_failed(cache_key, QStringLiteral("Artwork cache directory is unavailable"));
        return;
    }

    const QString digest = digest_for(artwork);
    const QString path = file_path_for(digest);
    if (validated_paths_.contains(path) && QFileInfo::exists(path)) {
        touch(path);
        QTimer::singleShot(0, this, [this, cache_key, path] { emit artwork_ready(cache_key, path); });
        return;
    }

    if (QFileInfo::exists(path)) {
        QString validation_error;
        if (validate_file(path, &validation_error)) {
            validated_paths_.insert(path);
            touch(path);
            QTimer::singleShot(0, this,
                               [this, cache_key, path] { emit artwork_ready(cache_key, path); });
            return;
        }
        QFile::remove(path);
    }

    if (in_flight_.contains(digest)) {
        return;
    }
    if (retry_after_ms_.value(digest, 0) > QDateTime::currentMSecsSinceEpoch()) {
        return;
    }

    QNetworkRequest network_request{url};
    network_request.setRawHeader("Accept", "image/avif,image/webp,image/png,image/jpeg,image/*;q=0.8");
    network_request.setHeader(
        QNetworkRequest::UserAgentHeader,
        QStringLiteral("OBS-Now-Playing/%1").arg(QStringLiteral(NOWPLAYING_PLUGIN_VERSION)));
    network_request.setAttribute(QNetworkRequest::RedirectPolicyAttribute,
                                 QNetworkRequest::NoLessSafeRedirectPolicy);

    QNetworkReply* reply = network_.get(network_request);
    reply->setProperty("artwork_cache_key", cache_key);
    reply->setProperty("artwork_digest", digest);
    reply->setProperty("artwork_path", path);
    in_flight_.insert(digest, reply);

    connect(reply, &QNetworkReply::downloadProgress, this,
            [reply](qint64 received, qint64 total) {
                if (received > maximum_download_bytes || total > maximum_download_bytes) {
                    reply->setProperty("artwork_too_large", true);
                    reply->abort();
                }
            });
    connect(reply, &QNetworkReply::finished, this, [this, reply] { handle_finished(reply); });
    QTimer::singleShot(request_timeout_ms, reply, [reply] {
        if (reply->isRunning()) {
            reply->setProperty("artwork_timed_out", true);
            reply->abort();
        }
    });
}

QString ArtworkCache::cache_directory() const
{
    return cache_directory_;
}

QString ArtworkCache::digest_for(const ArtworkReference& artwork) const
{
    const QByteArray identity = QStringLiteral("%1\n%2")
                                    .arg(QString::fromStdString(artwork.cache_key),
                                         QString::fromStdString(artwork.url))
                                    .toUtf8();
    return QString::fromLatin1(QCryptographicHash::hash(identity, QCryptographicHash::Sha256).toHex());
}

QString ArtworkCache::file_path_for(const QString& digest) const
{
    return QDir(cache_directory_).filePath(digest + QStringLiteral(".artwork"));
}

bool ArtworkCache::validate_file(const QString& path, QString* error) const
{
    QFile file(path);
    if (!file.open(QIODevice::ReadOnly)) {
        if (error) {
            *error = QStringLiteral("Cached artwork could not be opened");
        }
        return false;
    }
    if (file.size() <= 0 || file.size() > maximum_download_bytes) {
        if (error) {
            *error = QStringLiteral("Cached artwork has an invalid size");
        }
        return false;
    }
    return validate_bytes(file.readAll(), error);
}

bool ArtworkCache::validate_bytes(const QByteArray& bytes, QString* error) const
{
    if (bytes.isEmpty() || bytes.size() > maximum_download_bytes) {
        if (error) {
            *error = QStringLiteral("Artwork download has an invalid size");
        }
        return false;
    }

    QBuffer buffer;
    buffer.setData(bytes);
    if (!buffer.open(QIODevice::ReadOnly)) {
        if (error) {
            *error = QStringLiteral("Artwork data could not be inspected");
        }
        return false;
    }

    QImageReader reader(&buffer);
    reader.setAutoDetectImageFormat(true);
    reader.setDecideFormatFromContent(true);
    reader.setAutoTransform(false);
    if (!reader.canRead()) {
        if (error) {
            *error = QStringLiteral("Artwork is not a supported image: %1").arg(reader.errorString());
        }
        return false;
    }

    const QSize dimensions = reader.size();
    if (!dimensions.isValid() || dimensions.width() <= 0 || dimensions.height() <= 0 ||
        dimensions.width() > maximum_image_dimension || dimensions.height() > maximum_image_dimension ||
        static_cast<qint64>(dimensions.width()) * dimensions.height() > maximum_image_pixels) {
        if (error) {
            *error = QStringLiteral("Artwork dimensions are invalid or too large");
        }
        return false;
    }

    const QImage decoded = reader.read();
    if (decoded.isNull()) {
        if (error) {
            *error = QStringLiteral("Artwork could not be decoded: %1").arg(reader.errorString());
        }
        return false;
    }
    return true;
}

void ArtworkCache::handle_finished(QNetworkReply* reply)
{
    const QString cache_key = reply->property("artwork_cache_key").toString();
    const QString digest = reply->property("artwork_digest").toString();
    const QString path = reply->property("artwork_path").toString();
    in_flight_.remove(digest);

    const bool too_large = reply->property("artwork_too_large").toBool();
    const bool timed_out = reply->property("artwork_timed_out").toBool();
    const int status_code = reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();
    const QString content_type = reply->header(QNetworkRequest::ContentTypeHeader).toString().toLower();
    const QUrl final_url = reply->url();
    const QString network_error = reply->error() == QNetworkReply::NoError ? QString{} : reply->errorString();
    const QByteArray bytes = reply->readAll();
    reply->deleteLater();

    if (too_large) {
        fail(cache_key, digest, QStringLiteral("Artwork download exceeded 12 MB"));
        return;
    }
    if (timed_out) {
        fail(cache_key, digest, QStringLiteral("Artwork download timed out"));
        return;
    }
    if (status_code < 200 || status_code >= 300 || !network_error.isEmpty()) {
        fail(cache_key, digest,
             network_error.isEmpty()
                 ? QStringLiteral("Artwork request failed with HTTP %1").arg(status_code)
                 : network_error);
        return;
    }
    if (final_url.scheme() != QStringLiteral("https")) {
        fail(cache_key, digest, QStringLiteral("Artwork redirected to a non-HTTPS address"));
        return;
    }
    if (!content_type.isEmpty() && !content_type.startsWith(QStringLiteral("image/")) &&
        content_type != QStringLiteral("application/octet-stream")) {
        fail(cache_key, digest, QStringLiteral("Artwork server returned a non-image content type"));
        return;
    }

    QString validation_error;
    if (!validate_bytes(bytes, &validation_error)) {
        fail(cache_key, digest, validation_error);
        return;
    }

    QSaveFile output(path);
    if (!output.open(QIODevice::WriteOnly) || output.write(bytes) != bytes.size() || !output.commit()) {
        output.cancelWriting();
        fail(cache_key, digest, QStringLiteral("Artwork could not be written to the cache"));
        return;
    }

    QFile::setPermissions(path, QFileDevice::ReadOwner | QFileDevice::WriteOwner);
    validated_paths_.insert(path);
    retry_after_ms_.remove(digest);
    touch(path);
    enforce_limits();
    emit artwork_ready(cache_key, path);
}

void ArtworkCache::fail(const QString& cache_key, const QString& digest, const QString& message)
{
    retry_after_ms_.insert(digest, QDateTime::currentMSecsSinceEpoch() + failure_retry_delay_ms);
    emit artwork_failed(cache_key, message);
}

void ArtworkCache::touch(const QString& path) const
{
    QFile file(path);
    if (file.open(QIODevice::ReadWrite)) {
        file.setFileTime(QDateTime::currentDateTimeUtc(), QFileDevice::FileModificationTime);
    }
}

void ArtworkCache::enforce_limits()
{
    if (cache_directory_.isEmpty()) {
        return;
    }

    QDir directory(cache_directory_);
    QFileInfoList files = directory.entryInfoList(QStringList{QStringLiteral("*.artwork")}, QDir::Files,
                                                   QDir::Time | QDir::Reversed);
    qint64 total_bytes = 0;
    for (const QFileInfo& file : std::as_const(files)) {
        total_bytes += file.size();
    }

    while (!files.isEmpty() &&
           (files.size() > maximum_cache_files || total_bytes > maximum_cache_bytes)) {
        const QFileInfo oldest = files.takeFirst();
        if (QFile::remove(oldest.absoluteFilePath())) {
            validated_paths_.remove(oldest.absoluteFilePath());
            total_bytes -= oldest.size();
        }
    }
}

} // namespace now_playing
