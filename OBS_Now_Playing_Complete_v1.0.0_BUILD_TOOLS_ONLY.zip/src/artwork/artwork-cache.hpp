#pragma once

#include "../core/track-state.hpp"

#include <QHash>
#include <QNetworkAccessManager>
#include <QObject>
#include <QPointer>
#include <QSet>
#include <QString>

class QNetworkReply;

namespace now_playing {

class ArtworkCache final : public QObject {
    Q_OBJECT

public:
    explicit ArtworkCache(QObject* parent = nullptr);
    ~ArtworkCache() override;

    void request(const ArtworkReference& artwork);
    [[nodiscard]] QString cache_directory() const;

signals:
    void artwork_ready(const QString& cache_key, const QString& local_path);
    void artwork_failed(const QString& cache_key, const QString& message);

private:
    [[nodiscard]] QString digest_for(const ArtworkReference& artwork) const;
    [[nodiscard]] QString file_path_for(const QString& digest) const;
    [[nodiscard]] bool validate_file(const QString& path, QString* error) const;
    [[nodiscard]] bool validate_bytes(const QByteArray& bytes, QString* error) const;
    void handle_finished(QNetworkReply* reply);
    void fail(const QString& cache_key, const QString& digest, const QString& message);
    void touch(const QString& path) const;
    void enforce_limits();

    QString cache_directory_;
    QNetworkAccessManager network_;
    QHash<QString, QPointer<QNetworkReply>> in_flight_;
    QHash<QString, qint64> retry_after_ms_;
    QSet<QString> validated_paths_;
};

} // namespace now_playing

