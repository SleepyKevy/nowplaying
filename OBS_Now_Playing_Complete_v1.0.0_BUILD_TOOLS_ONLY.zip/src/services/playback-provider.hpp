#pragma once

#include "../core/track-state.hpp"

#include <functional>
#include <string>

namespace now_playing {

class PlaybackProvider {
public:
    using StateHandler = std::function<void(const TrackState&)>;
    using ErrorHandler = std::function<void(const std::string&)>;

    virtual ~PlaybackProvider() = default;

    virtual void start(StateHandler on_state, ErrorHandler on_error) = 0;
    virtual void stop() = 0;
    [[nodiscard]] virtual bool is_connected() const noexcept = 0;
};

} // namespace now_playing

