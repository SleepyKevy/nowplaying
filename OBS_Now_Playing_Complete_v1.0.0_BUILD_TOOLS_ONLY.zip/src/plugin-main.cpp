#include "artwork/artwork-cache.hpp"
#include "core/playback-state-store.hpp"
#include "obs/now-playing-source.hpp"
#include "spotify/spotify-auth-manager.hpp"
#include "spotify/spotify-playback-provider.hpp"
#include "ui/spotify-connection-dialog.hpp"

#include <obs-module.h>
#include <obs-frontend-api.h>

#include <QAction>
#include <QApplication>
#include <QPointer>

#include <memory>
#include <string>
#include <utility>

OBS_DECLARE_MODULE()
OBS_MODULE_USE_DEFAULT_LOCALE("obs-now-playing", "en-US")

namespace {

std::unique_ptr<now_playing::SpotifyAuthManager> spotify_auth;
std::unique_ptr<now_playing::PlaybackStateStore> playback_state;
std::unique_ptr<now_playing::SpotifyPlaybackProvider> playback_provider;
std::unique_ptr<now_playing::ArtworkCache> artwork_cache;
QPointer<now_playing::SpotifyConnectionDialog> connection_dialog;
QPointer<QAction> connection_action;

void show_spotify_connection()
{
    if (!spotify_auth || !playback_state) {
        return;
    }

    if (!connection_dialog) {
        connection_dialog = new now_playing::SpotifyConnectionDialog(*spotify_auth, *playback_state,
                                                                      QApplication::activeWindow());
        connection_dialog->setAttribute(Qt::WA_DeleteOnClose);
    }

    connection_dialog->show();
    connection_dialog->raise();
    connection_dialog->activateWindow();
}

} // namespace

MODULE_EXPORT const char* obs_module_description()
{
    return "Customizable Now Playing source with Spotify artwork integration";
}

MODULE_EXPORT const char* obs_module_name()
{
    return "OBS Now Playing";
}

MODULE_EXPORT const char* obs_module_author()
{
    return "SleepyKev";
}

bool obs_module_load()
{
    spotify_auth = std::make_unique<now_playing::SpotifyAuthManager>();
    playback_state = std::make_unique<now_playing::PlaybackStateStore>();
    now_playing::set_now_playing_playback_store(playback_state.get());
    obs_register_source(&now_playing_source_info);
    artwork_cache = std::make_unique<now_playing::ArtworkCache>();
    QObject::connect(artwork_cache.get(), &now_playing::ArtworkCache::artwork_ready,
                     [](const QString& cache_key, const QString& local_path) {
                         if (!playback_state) {
                             return;
                         }
                         now_playing::TrackState state = playback_state->snapshot();
                         if (QString::fromStdString(state.artwork.cache_key) != cache_key ||
                             state.artwork.local_path == local_path.toStdString()) {
                             return;
                         }
                         state.artwork.local_path = local_path.toStdString();
                         playback_state->update(std::move(state));
                     });
    QObject::connect(artwork_cache.get(), &now_playing::ArtworkCache::artwork_failed,
                     [](const QString&, const QString& error) {
                         blog(LOG_WARNING, "[obs-now-playing] Spotify artwork: %s",
                              error.toUtf8().constData());
                     });
    playback_provider = std::make_unique<now_playing::SpotifyPlaybackProvider>(*spotify_auth);
    playback_provider->start(
        [](const now_playing::TrackState& state) {
            if (playback_state) {
                now_playing::TrackState updated = state;
                const now_playing::TrackState current = playback_state->snapshot();
                if (updated.artwork.cache_key == current.artwork.cache_key &&
                    updated.artwork.url == current.artwork.url) {
                    updated.artwork.local_path = current.artwork.local_path;
                }
                playback_state->update(updated);
                if (artwork_cache && updated.artwork.local_path.empty() &&
                    !updated.artwork.url.empty()) {
                    artwork_cache->request(updated.artwork);
                }
            }
        },
        [](const std::string& error) {
            blog(LOG_WARNING, "[obs-now-playing] Spotify playback: %s", error.c_str());
        });
    connection_action = static_cast<QAction*>(
        obs_frontend_add_tools_menu_qaction(obs_module_text("SpotifyConnection.Menu")));
    QObject::connect(connection_action, &QAction::triggered, [] { show_spotify_connection(); });

    blog(LOG_INFO, "[obs-now-playing] Loaded version %s", NOWPLAYING_PLUGIN_VERSION);
    return true;
}

void obs_module_unload()
{
    if (connection_dialog) {
        delete connection_dialog;
        connection_dialog = nullptr;
    }
    if (connection_action) {
        delete connection_action;
        connection_action = nullptr;
    }
    if (playback_provider) {
        playback_provider->stop();
    }
    playback_provider.reset();
    artwork_cache.reset();
    now_playing::set_now_playing_playback_store(nullptr);
    playback_state.reset();
    spotify_auth.reset();
    blog(LOG_INFO, "[obs-now-playing] Unloaded");
}
