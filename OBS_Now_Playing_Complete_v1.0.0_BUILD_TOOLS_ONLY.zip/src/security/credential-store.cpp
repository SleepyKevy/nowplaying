#include "credential-store.hpp"

#ifdef _WIN32
#include <windows.h>
#include <wincred.h>
#endif

#include <string>

namespace now_playing {

#ifdef _WIN32
namespace {

std::wstring to_wide(const QString& value)
{
    return value.toStdWString();
}

void set_windows_error(QString* error, const QString& action)
{
    if (error) {
        *error = QStringLiteral("%1 failed with Windows error %2").arg(action).arg(GetLastError());
    }
}

} // namespace
#endif

bool CredentialStore::write(const QString& target, const QByteArray& value, QString* error)
{
#ifdef _WIN32
    if (value.size() > CRED_MAX_CREDENTIAL_BLOB_SIZE) {
        if (error) {
            *error = QStringLiteral("Credential data is too large");
        }
        return false;
    }

    const auto wide_target = to_wide(target);
    const auto wide_username = std::wstring(L"Spotify OAuth");
    CREDENTIALW credential{};
    credential.Type = CRED_TYPE_GENERIC;
    credential.TargetName = const_cast<wchar_t*>(wide_target.c_str());
    credential.CredentialBlobSize = static_cast<DWORD>(value.size());
    credential.CredentialBlob = reinterpret_cast<LPBYTE>(const_cast<char*>(value.constData()));
    credential.Persist = CRED_PERSIST_LOCAL_MACHINE;
    credential.UserName = const_cast<wchar_t*>(wide_username.c_str());

    if (!CredWriteW(&credential, 0)) {
        set_windows_error(error, QStringLiteral("Saving Spotify credentials"));
        return false;
    }
    return true;
#else
    Q_UNUSED(target)
    Q_UNUSED(value)
    if (error) {
        *error = QStringLiteral("Secure credential storage is only implemented for Windows");
    }
    return false;
#endif
}

std::optional<QByteArray> CredentialStore::read(const QString& target, QString* error)
{
#ifdef _WIN32
    const auto wide_target = to_wide(target);
    PCREDENTIALW credential = nullptr;
    if (!CredReadW(wide_target.c_str(), CRED_TYPE_GENERIC, 0, &credential)) {
        if (GetLastError() == ERROR_NOT_FOUND) {
            return std::nullopt;
        }
        set_windows_error(error, QStringLiteral("Reading Spotify credentials"));
        return std::nullopt;
    }

    const QByteArray value(reinterpret_cast<const char*>(credential->CredentialBlob),
                           static_cast<qsizetype>(credential->CredentialBlobSize));
    CredFree(credential);
    return value;
#else
    Q_UNUSED(target)
    if (error) {
        *error = QStringLiteral("Secure credential storage is only implemented for Windows");
    }
    return std::nullopt;
#endif
}

bool CredentialStore::remove(const QString& target, QString* error)
{
#ifdef _WIN32
    const auto wide_target = to_wide(target);
    if (!CredDeleteW(wide_target.c_str(), CRED_TYPE_GENERIC, 0)) {
        if (GetLastError() == ERROR_NOT_FOUND) {
            return true;
        }
        set_windows_error(error, QStringLiteral("Deleting Spotify credentials"));
        return false;
    }
    return true;
#else
    Q_UNUSED(target)
    if (error) {
        *error = QStringLiteral("Secure credential storage is only implemented for Windows");
    }
    return false;
#endif
}

} // namespace now_playing
