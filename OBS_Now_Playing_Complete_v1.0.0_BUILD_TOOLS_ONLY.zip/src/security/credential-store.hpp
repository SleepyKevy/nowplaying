#pragma once

#include <QByteArray>
#include <QString>

#include <optional>

namespace now_playing {

class CredentialStore {
public:
    static bool write(const QString& target, const QByteArray& value, QString* error = nullptr);
    static std::optional<QByteArray> read(const QString& target, QString* error = nullptr);
    static bool remove(const QString& target, QString* error = nullptr);
};

} // namespace now_playing

