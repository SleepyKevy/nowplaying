#include "spotify-connection-dialog.hpp"

#include "../spotify/spotify-auth-manager.hpp"
#include "../core/playback-state-store.hpp"

#include <obs-module.h>

#include <QApplication>
#include <QClipboard>
#include <QFormLayout>
#include <QFont>
#include <QFrame>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QPixmap>
#include <QVBoxLayout>

#include <algorithm>
#include <cstdint>

namespace now_playing {
namespace {

QString format_time(std::int64_t milliseconds)
{
    const std::int64_t total_seconds = std::max<std::int64_t>(0, milliseconds / 1'000);
    const std::int64_t minutes = total_seconds / 60;
    const std::int64_t seconds = total_seconds % 60;
    return QStringLiteral("%1:%2").arg(minutes).arg(seconds, 2, 10, QLatin1Char('0'));
}

QString playback_status_text(PlaybackStatus status)
{
    switch (status) {
    case PlaybackStatus::playing:
        return obs_module_text("SpotifyPlayback.Playing");
    case PlaybackStatus::paused:
        return obs_module_text("SpotifyPlayback.Paused");
    case PlaybackStatus::stopped:
        return obs_module_text("SpotifyPlayback.NothingPlaying");
    case PlaybackStatus::unavailable:
    default:
        return obs_module_text("SpotifyPlayback.Unavailable");
    }
}

} // namespace

SpotifyConnectionDialog::SpotifyConnectionDialog(SpotifyAuthManager& auth, PlaybackStateStore& playback,
                                                 QWidget* parent)
    : QDialog(parent), auth_(auth), playback_(playback)
{
    setWindowTitle(obs_module_text("SpotifyConnection.Title"));
    setMinimumWidth(560);
    setModal(false);

    auto* root = new QVBoxLayout(this);
    auto* client_help = new QLabel(obs_module_text("SpotifyConnection.ClientIdHelp"), this);
    client_help->setWordWrap(true);
    root->addWidget(client_help);

    auto* form = new QFormLayout;
    client_id_ = new QLineEdit(auth_.client_id(), this);
    client_id_->setPlaceholderText(QStringLiteral("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"));
    form->addRow(obs_module_text("SpotifyConnection.ClientId"), client_id_);

    auto* redirect_row = new QWidget(this);
    auto* redirect_layout = new QHBoxLayout(redirect_row);
    redirect_layout->setContentsMargins(0, 0, 0, 0);
    auto* redirect = new QLineEdit(QStringLiteral("http://127.0.0.1/callback"), redirect_row);
    redirect->setReadOnly(true);
    auto* copy = new QPushButton(obs_module_text("SpotifyConnection.Copy"), redirect_row);
    redirect_layout->addWidget(redirect, 1);
    redirect_layout->addWidget(copy);
    form->addRow(obs_module_text("SpotifyConnection.RedirectUri"), redirect_row);
    root->addLayout(form);

    auto* redirect_help = new QLabel(obs_module_text("SpotifyConnection.RedirectHelp"), this);
    redirect_help->setWordWrap(true);
    root->addWidget(redirect_help);

    auto* separator = new QFrame(this);
    separator->setFrameShape(QFrame::HLine);
    root->addWidget(separator);

    status_ = new QLabel(this);
    status_->setWordWrap(true);
    root->addWidget(status_);

    auto* playback_separator = new QFrame(this);
    playback_separator->setFrameShape(QFrame::HLine);
    root->addWidget(playback_separator);

    auto* playback_heading = new QLabel(obs_module_text("SpotifyPlayback.LiveHeading"), this);
    QFont heading_font = playback_heading->font();
    heading_font.setBold(true);
    playback_heading->setFont(heading_font);
    root->addWidget(playback_heading);

    artwork_preview_ = new QLabel(this);
    artwork_preview_->setFixedSize(96, 96);
    artwork_preview_->setAlignment(Qt::AlignCenter);
    artwork_preview_->setText(obs_module_text("SpotifyPlayback.NoArtwork"));
    root->addWidget(artwork_preview_, 0, Qt::AlignLeft);

    track_title_ = new QLabel(obs_module_text("SpotifyPlayback.NothingPlaying"), this);
    QFont title_font = track_title_->font();
    title_font.setPointSize(title_font.pointSize() + 2);
    title_font.setBold(true);
    track_title_->setFont(title_font);
    track_title_->setWordWrap(true);
    root->addWidget(track_title_);

    track_artist_ = new QLabel(this);
    track_artist_->setWordWrap(true);
    root->addWidget(track_artist_);
    track_album_ = new QLabel(this);
    track_album_->setWordWrap(true);
    root->addWidget(track_album_);
    track_progress_ = new QLabel(this);
    root->addWidget(track_progress_);

    auto* actions = new QHBoxLayout;
    connect_button_ = new QPushButton(obs_module_text("SpotifyConnection.Connect"), this);
    disconnect_button_ = new QPushButton(obs_module_text("SpotifyConnection.Disconnect"), this);
    auto* close_button = new QPushButton(obs_module_text("SpotifyConnection.Close"), this);
    actions->addWidget(connect_button_);
    actions->addWidget(disconnect_button_);
    actions->addStretch(1);
    actions->addWidget(close_button);
    root->addLayout(actions);

    connect(copy, &QPushButton::clicked, this,
            [redirect] { QApplication::clipboard()->setText(redirect->text()); });
    connect(close_button, &QPushButton::clicked, this, &QDialog::close);
    connect(connect_button_, &QPushButton::clicked, this, [this] {
        auth_.set_client_id(client_id_->text());
        auth_.connect_spotify();
    });
    connect(disconnect_button_, &QPushButton::clicked, &auth_, &SpotifyAuthManager::disconnect_spotify);
    connect(&auth_, &SpotifyAuthManager::status_changed, this,
            [this](SpotifyAuthManager::Status, const QString&) { update_status(); });
    connect(client_id_, &QLineEdit::textChanged, this,
            [this](const QString& value) { connect_button_->setEnabled(!value.trimmed().isEmpty()); });

    preview_timer_.setInterval(500);
    connect(&preview_timer_, &QTimer::timeout, this,
            &SpotifyConnectionDialog::update_playback_preview);
    preview_timer_.start();

    update_status();
    update_playback_preview();
}

void SpotifyConnectionDialog::update_status()
{
    status_->setText(QStringLiteral("%1: %2")
                         .arg(obs_module_text("SpotifyConnection.Status"), auth_.status_message()));
    const auto current = auth_.status();
    const bool busy = current == SpotifyAuthManager::Status::waiting_for_browser ||
                      current == SpotifyAuthManager::Status::exchanging_code;
    connect_button_->setEnabled(!busy && !client_id_->text().trimmed().isEmpty());
    disconnect_button_->setEnabled(current != SpotifyAuthManager::Status::disconnected);
}

void SpotifyConnectionDialog::update_playback_preview()
{
    const TrackState state = playback_.snapshot();
    if (!state.has_content()) {
        artwork_preview_->setProperty("artwork_path", QString{});
        artwork_preview_->setPixmap(QPixmap{});
        artwork_preview_->setText(obs_module_text("SpotifyPlayback.NoArtwork"));
        track_title_->setText(playback_status_text(state.status));
        track_artist_->clear();
        track_album_->clear();
        track_progress_->clear();
        return;
    }

    const QString artwork_path = QString::fromStdString(state.artwork.local_path);
    if (artwork_preview_->property("artwork_path").toString() != artwork_path) {
        artwork_preview_->setProperty("artwork_path", artwork_path);
        QPixmap artwork(artwork_path);
        if (artwork.isNull()) {
            artwork_preview_->setPixmap(QPixmap{});
            artwork_preview_->setText(obs_module_text("SpotifyPlayback.NoArtwork"));
        } else {
            artwork_preview_->setText(QString{});
            artwork_preview_->setPixmap(
                artwork.scaled(artwork_preview_->size(), Qt::KeepAspectRatio,
                               Qt::SmoothTransformation));
        }
    }

    track_title_->setText(QString::fromStdString(state.title));
    if (state.artists.empty()) {
        track_artist_->clear();
    } else {
        track_artist_->setText(QStringLiteral("%1: %2")
                                   .arg(obs_module_text("SpotifyPlayback.Artist"),
                                        QString::fromStdString(state.artists)));
    }
    if (state.album.empty()) {
        track_album_->clear();
    } else {
        track_album_->setText(QStringLiteral("%1: %2")
                                  .arg(obs_module_text("SpotifyPlayback.Album"),
                                       QString::fromStdString(state.album)));
    }
    track_progress_->setText(QStringLiteral("%1  •  %2 / %3")
                                 .arg(playback_status_text(state.status),
                                      format_time(state.estimated_progress_ms()),
                                      format_time(state.duration_ms)));
}

} // namespace now_playing
