#pragma once

#include <QDialog>
#include <QTimer>

class QLabel;
class QLineEdit;
class QPushButton;

namespace now_playing {

class SpotifyAuthManager;
class PlaybackStateStore;

class SpotifyConnectionDialog final : public QDialog {
    Q_OBJECT

public:
    explicit SpotifyConnectionDialog(SpotifyAuthManager& auth, PlaybackStateStore& playback,
                                     QWidget* parent = nullptr);

private:
    void update_status();
    void update_playback_preview();

    SpotifyAuthManager& auth_;
    PlaybackStateStore& playback_;
    QLineEdit* client_id_ = nullptr;
    QLabel* status_ = nullptr;
    QLabel* artwork_preview_ = nullptr;
    QLabel* track_title_ = nullptr;
    QLabel* track_artist_ = nullptr;
    QLabel* track_album_ = nullptr;
    QLabel* track_progress_ = nullptr;
    QPushButton* connect_button_ = nullptr;
    QPushButton* disconnect_button_ = nullptr;
    QTimer preview_timer_;
};

} // namespace now_playing
