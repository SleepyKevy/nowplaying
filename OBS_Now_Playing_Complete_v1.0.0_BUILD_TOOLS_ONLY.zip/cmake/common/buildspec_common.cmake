# Common OBS plugin build dependencies module.
# Derived from obsproject/obs-plugintemplate's bootstrap so Windows builds can
# fetch matching OBS and Qt development dependencies automatically.

include_guard(GLOBAL)

function(_check_deps_version version)
    set(found FALSE)

    foreach(path IN LISTS CMAKE_PREFIX_PATH)
        if(EXISTS "${path}/share/obs-deps/VERSION")
            if(dependency STREQUAL qt6 AND NOT EXISTS "${path}/lib/cmake/Qt6/Qt6Config.cmake")
                set(found FALSE)
                continue()
            endif()

            file(READ "${path}/share/obs-deps/VERSION" _check_version)
            string(REPLACE "\n" "" _check_version "${_check_version}")
            string(REPLACE "-" "." _check_version "${_check_version}")
            string(REPLACE "-" "." version "${version}")

            if(_check_version VERSION_EQUAL version)
                set(found TRUE)
                break()
            elseif(_check_version VERSION_LESS version)
                message(AUTHOR_WARNING "Older ${label} version detected in ${path}: found ${_check_version}, require ${version}")
                list(REMOVE_ITEM CMAKE_PREFIX_PATH "${path}")
                list(APPEND CMAKE_PREFIX_PATH "${path}")
                set(CMAKE_PREFIX_PATH ${CMAKE_PREFIX_PATH})
            else()
                message(AUTHOR_WARNING "Newer ${label} version detected in ${path}: found ${_check_version}, require ${version}")
                set(found TRUE)
                break()
            endif()
        endif()
    endforeach()

    return(PROPAGATE found CMAKE_PREFIX_PATH)
endfunction()

function(_setup_obs_studio)
    if(NOT libobs_DIR)
        set(_is_fresh --fresh)
    endif()

    set(_obs_build_dir "${dependencies_dir}/${_obs_destination}/build_${arch}")

    if(CMAKE_VS_WINDOWS_TARGET_PLATFORM_VERSION)
        set(_obs_architecture "${arch},version=${CMAKE_VS_WINDOWS_TARGET_PLATFORM_VERSION}")
    else()
        set(_obs_architecture "${arch}")
    endif()

    message(STATUS "Configuring ${label} (${arch})")
    execute_process(
        COMMAND
            "${CMAKE_COMMAND}"
            -S "${dependencies_dir}/${_obs_destination}"
            -B "${_obs_build_dir}"
            -G "${CMAKE_GENERATOR}"
            -A "${_obs_architecture}"
            -DOBS_CMAKE_VERSION:STRING=3.0.0
            -DENABLE_PLUGINS:BOOL=OFF
            -DENABLE_FRONTEND:BOOL=OFF
            -DCMAKE_ENABLE_SCRIPTING:BOOL=OFF
            -DOBS_VERSION_OVERRIDE:STRING=${_obs_version}
            "-DCMAKE_PREFIX_PATH=${CMAKE_PREFIX_PATH}"
            ${_is_fresh}
        RESULT_VARIABLE _process_result
        COMMAND_ERROR_IS_FATAL ANY
        OUTPUT_QUIET
    )
    message(STATUS "Configuring ${label} (${arch}) - done")

    foreach(_obs_config Debug Release)
        message(STATUS "Building ${label} development SDK (${_obs_config} - ${arch})")
        execute_process(
            COMMAND "${CMAKE_COMMAND}" --build "${_obs_build_dir}" --target obs-frontend-api --config ${_obs_config} --parallel
            RESULT_VARIABLE _process_result
            COMMAND_ERROR_IS_FATAL ANY
            OUTPUT_QUIET
        )
        message(STATUS "Building ${label} development SDK (${_obs_config} - ${arch}) - done")

        message(STATUS "Installing ${label} development SDK (${_obs_config} - ${arch})")
        execute_process(
            COMMAND
                "${CMAKE_COMMAND}" --install "${_obs_build_dir}" --component Development --config ${_obs_config} --prefix "${dependencies_dir}"
            RESULT_VARIABLE _process_result
            COMMAND_ERROR_IS_FATAL ANY
            OUTPUT_QUIET
        )
        message(STATUS "Installing ${label} development SDK (${_obs_config} - ${arch}) - done")
    endforeach()
endfunction()

function(_check_dependencies)
    file(MAKE_DIRECTORY "${dependencies_dir}")
    file(READ "${CMAKE_CURRENT_SOURCE_DIR}/buildspec.json" buildspec)
    string(JSON dependency_data GET ${buildspec} dependencies)

    foreach(dependency IN LISTS dependencies_list)
        string(JSON data GET ${dependency_data} ${dependency})
        string(JSON version GET ${data} version)
        string(JSON hash GET ${data} hashes ${platform})
        string(JSON url GET ${data} baseUrl)
        string(JSON label GET ${data} label)
        string(JSON revision ERROR_VARIABLE revision_error GET ${data} revision ${platform})

        if(revision_error)
            unset(revision)
        endif()

        message(STATUS "Setting up ${label} (${arch})")

        set(file "${${dependency}_filename}")
        set(destination "${${dependency}_destination}")
        string(REPLACE "VERSION" "${version}" file "${file}")
        string(REPLACE "VERSION" "${version}" destination "${destination}")
        string(REPLACE "ARCH" "${arch}" file "${file}")
        string(REPLACE "ARCH" "${arch}" destination "${destination}")

        if(revision)
            string(REPLACE "_REVISION" "_v${revision}" file "${file}")
            string(REPLACE "-REVISION" "-v${revision}" file "${file}")
        else()
            string(REPLACE "_REVISION" "" file "${file}")
            string(REPLACE "-REVISION" "" file "${file}")
        endif()

        set(hash_file "${dependencies_dir}/.dependency_${dependency}_${arch}.sha256")
        set(previous_hash "")
        if(EXISTS "${hash_file}")
            file(READ "${hash_file}" previous_hash)
        endif()

        set(skip FALSE)
        if((dependency STREQUAL prebuilt OR dependency STREQUAL qt6) AND previous_hash STREQUAL hash)
            _check_deps_version(${version})
            if(found)
                set(skip TRUE)
            endif()
        endif()

        if(skip)
            message(STATUS "Setting up ${label} (${arch}) - cached")
            continue()
        endif()

        if(dependency STREQUAL obs-studio)
            set(download_url "${url}/${file}")
        else()
            set(download_url "${url}/${version}/${file}")
        endif()

        if(NOT EXISTS "${dependencies_dir}/${file}")
            message(STATUS "Downloading ${label}: ${download_url}")
            file(
                DOWNLOAD "${download_url}" "${dependencies_dir}/${file}"
                STATUS download_status
                EXPECTED_HASH SHA256=${hash}
                SHOW_PROGRESS
            )
            list(GET download_status 0 error_code)
            list(GET download_status 1 error_message)
            if(error_code GREATER 0)
                file(REMOVE "${dependencies_dir}/${file}")
                message(FATAL_ERROR "Unable to download ${download_url}: ${error_message}")
            endif()
        else()
            file(SHA256 "${dependencies_dir}/${file}" existing_hash)
            if(NOT existing_hash STREQUAL hash)
                file(REMOVE "${dependencies_dir}/${file}")
                message(FATAL_ERROR "Cached dependency ${file} has the wrong SHA256. Re-run configure to download it again.")
            endif()
        endif()

        if(NOT previous_hash STREQUAL hash)
            file(REMOVE_RECURSE "${dependencies_dir}/${destination}")
        endif()

        if(NOT EXISTS "${dependencies_dir}/${destination}")
            file(MAKE_DIRECTORY "${dependencies_dir}/${destination}")
            if(dependency STREQUAL obs-studio)
                # GitHub's tag ZIP already contains obs-studio-VERSION as its top-level directory.
                file(ARCHIVE_EXTRACT INPUT "${dependencies_dir}/${file}" DESTINATION "${dependencies_dir}")
            else()
                file(ARCHIVE_EXTRACT INPUT "${dependencies_dir}/${file}" DESTINATION "${dependencies_dir}/${destination}")
            endif()
        endif()

        file(WRITE "${hash_file}" "${hash}")

        if(dependency STREQUAL prebuilt OR dependency STREQUAL qt6)
            list(APPEND CMAKE_PREFIX_PATH "${dependencies_dir}/${destination}")
        elseif(dependency STREQUAL obs-studio)
            set(_obs_version ${version})
            set(_obs_destination "${destination}")
            list(APPEND CMAKE_PREFIX_PATH "${dependencies_dir}")
        endif()

        message(STATUS "Setting up ${label} (${arch}) - done")
    endforeach()

    list(REMOVE_DUPLICATES CMAKE_PREFIX_PATH)
    set(CMAKE_PREFIX_PATH ${CMAKE_PREFIX_PATH} CACHE PATH "CMake prefix search path" FORCE)

    _setup_obs_studio()
endfunction()
