# CMake Windows build dependencies module
# Based on the official obsproject/obs-plugintemplate dependency bootstrap.

include_guard(GLOBAL)

include(buildspec_common)

function(_check_dependencies_windows)
    set(arch ${CMAKE_VS_PLATFORM_NAME})
    string(TOLOWER "${arch}" arch)
    set(platform windows-${arch})
    set(dependencies_dir "${CMAKE_CURRENT_SOURCE_DIR}/.deps")

    set(prebuilt_filename "windows-deps-VERSION-ARCH-REVISION.zip")
    set(prebuilt_destination "obs-deps-VERSION-ARCH")
    set(qt6_filename "windows-deps-qt6-VERSION-ARCH-REVISION.zip")
    set(qt6_destination "obs-deps-qt6-VERSION-ARCH")
    set(obs-studio_filename "VERSION.zip")
    set(obs-studio_destination "obs-studio-VERSION")
    set(dependencies_list prebuilt qt6 obs-studio)

    _check_dependencies()
endfunction()

_check_dependencies_windows()
